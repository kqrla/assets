# what sculptura is

sculptura helps people turn an idea for metal jewelry into a piece they can offer for sale, without first learning professional cad, buying metal inventory, or setting up a workshop. it connects the creative work of designing a piece with the practical work of checking, selling, making, and delivering it. the creator makes the design decisions; sculptura handles the technical and operational path around those decisions.

## how it works

1. **create:** a creator describes and shapes a ring or other metal piece in the studio. tessa can interpret references and suggest adjustments to approved controls, but the creator accepts or changes the suggestions. paracraft, not tessa, builds the geometry from those parameters.
2. **check:** the creator sees an interactive browser preview. separately, the studio server rebuilds the approved design and checks the exact production geometry against manufacturing rules. only a design that passes server-side checks can become a versioned, immutable design release.
3. **offer:** the platform turns that release into a listing on the sculptura marketplace, a creator storefront, or a connected sales channel. a creator can choose either the earnings they want per sale or a retail price; the platform calculates the other value using current manufacturing and selling costs. creating an account alone does not make a creator discoverable.
4. **buy and make:** a buyer can purchase an ordinary listed piece without an account. the platform verifies a current price and an eligible route, then passes the exact release to an approved casting partner. the partner makes and finishes the jewelry in metal and ships it to the customer. sculptura coordinates the order, tracking, creator earnings, and exceptions.

creators may later choose to accept commissions. a commissioner must have an account and sends a brief to a creator, who remains the person using the studio. commissions require an actual conversation, terms, payment protection, approvals, and dispute process before they can be offered as a complete feature.

sculptura focuses on metal-only jewelry and does not supply stones. a future empty setting for a buyer-provided stone is a possibility, not a committed feature. shipping destinations, metals, and manufacturing partners become available only when their complete production and compliance routes are ready.

**the point:** more people with ideas and taste can become creators, sell their work without holding inventory, and rely on a reproducible design and a managed route from order to finished jewelry. the studio owns geometry; the platform owns listings and sales; manufacturing partners own physical production.

for the deeper explanation, start with [`explain/index.md`](explain/index.md). for what actually exists in today's source code, see the [file-by-file audit](audit/index.md). neither document claims the proposed full system is already live.
