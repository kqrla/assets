# risks and proof plan

venture language must distinguish the thesis from demonstrated capability.

## geometry and safety

**claim to prove:** paracraft consistently produces reproducible, casting-safe geometry.

proof requires:

- deterministic fixtures across supported project types
- rule coverage for wall, feature, clearance, cavity, shrinkage, envelope, and mass
- comparison between compiled assets and webgl display
- partner review of production files
- tracked casting failures and rule corrections

## tessa

**claim to prove:** creators can express visual intent without learning conventional cad.

proof requires:

- proposal acceptance and correction rates
- time to first satisfactory model
- successful completion by users without cad experience
- hard evidence that tessa cannot emit geometry or bypass bounds

## manufacturing network

**claim to prove:** distributed casters can receive normalized, validated orders and fulfill them reliably.

proof requires:

- commercial partner agreements
- capability verification
- live quote and order paths
- status and reconciliation behavior
- lead-time, defect, remake, cancellation, and delivery outcomes

an entry in a research file is not a connected partner.

## asset-light economics

**claim to prove:** high order value and low physical inventory produce attractive contribution margins.

proof requires fully loaded unit economics, including payment fees, support, defects, remakes, refunds, insurance, shipping exceptions, chargebacks, reserves, and partner-payment timing.

zero owned inventory does not prove positive cash flow.

## payment rails

**claim to prove:** creator splits and factory payments can be automated in target markets.

proof requires provider approval, connected-account coverage, charge and transfer design, dispute allocation, refund behavior, reserve requirements, and a supported factory-payment method.

stripe connect does not automatically remove platform accounting obligations. virtual cards remain an option until tested with providers and casters.

## compliance routing

**claim to prove:** software can block invalid routes and prepare the right tax, customs, and hallmarking treatment.

proof requires reviewed market rules, evidence dates, seller and dispatch models, applicable eu oss treatment, hallmarking and assay paths, customs data, sanctions controls, consumer terms, and route-level tests.

“compliance-aware” is appropriate before launch. “automatically compliant” is not.

## buyer and creator trust

**claim to prove:** people will buy emotionally important jewelry through a digital-first flow.

proof requires accurate previews, fit and sizing guidance, transparent materials, delivery reliability, responsive support, fair refunds and disputes, and strong post-delivery satisfaction.

## moat validation

**claim to prove:** operational learning compounds.

proof requires versioned links between parameters, compiler rules, quotes, routes, production outcomes, quality outcomes, and financial results. without that lineage, the proposed data moat does not exist.

## investor-claim rule

use three labels internally:

- **implemented:** working and tested in the product
- **contracted or verified:** confirmed with an external provider, partner, or reviewed rule
- **planned:** architecture or hypothesis that still requires delivery

never present planned rails, research candidates, shipping corridors, tax treatment, or manufacturing relationships as live facts.
