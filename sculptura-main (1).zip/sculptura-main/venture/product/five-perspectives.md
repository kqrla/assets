# five perspectives

sculptura is one physical asset loop seen through five interfaces.

## 01. the digital creator

this creator may be an illustrator, virtual-avatar designer, stylist, 2d concept artist, pinterest curator, or someone with strong taste and no manufacturing background.

for them, sculptura is a route to a metal-jewelry label without buying a torch, learning foundry operations, carrying precious-metal inventory, or personally shipping each order. they bring the point of view, direct the design, approve the release, and operate the storefront.

ordinary made-to-order listings are the first monetization path. commissions are an optional later toggle, not the prerequisite for becoming a creator.

## 02. the buyer who realizes they can create

traditional cad can resemble an airplane cockpit to a couple imagining wedding bands or a person who has only a mood board and a sentence such as, “liquid metal outside, incredibly smooth inside.”

sculptura can convert that realization into creator onboarding. the person does not receive unrestricted generation inside a buyer checkout. they become the creator of a private project, direct tessa and paracraft through the studio, and own the resulting design process.

this preserves an important boundary: buying a listed piece remains simple, while authoring a new piece carries creator identity, project history, review, and release responsibility.

## 03. tessa, the conversational operator

tessa's job is translation. she sits in the middle of the relay between human aesthetics and paracraft's rigid inputs.

she can interpret words such as organic, molten, brushed, folded, narrow, or smooth and map them to proposals for predefined numeric controls. she does not know how to invent a production mesh, and the architecture does not let her try.

this limitation is a feature. it keeps model inference out of geometric truth and turns misunderstandings into reviewable parameter proposals instead of hidden physical defects.

## 04. paracraft, the geometric truth

paracraft is the proprietary deterministic compiler framework built on openscad rails. it accepts the approved numeric parameters, constructs the exact model, and applies design-rule checks.

paracraft cares about math and physics:

- wall and feature thickness
- alloy and process shrinkage allowances
- clearances and connected parts
- cavities and castability
- build envelope
- volume and mass
- process-specific limits

if tessa proposes a value outside the permitted physical boundary, paracraft rejects or bounds it. the compiled openscad model is rendered through webgl for the creator, then the same build lineage feeds validation and release.

## 05. the distributed caster

casting partners do not want poorly modeled consumer files, ambiguous instructions, unpriced support work, or endless design conversations.

from their perspective, sculptura should be a clean demand and production pipeline:

- one validated release
- explicit alloy, size, finish, and quantity
- normalized production instructions
- an accepted quote and funded order
- required hallmarking and route documentation
- structured status, tracking, cancellation, and exception handling

partners keep doing the specialist work they already understand: pattern production, investment, burnout, casting, finishing, inspection, and shipping. sculptura improves the input and coordinates the surrounding state.
