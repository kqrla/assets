# moat and defensibility

sculptura's moat is not access to a general vision model. models can change. the defensibility comes from the deterministic and operational system that makes taste manufacturable and orders fulfillable.

## 1. paracraft's jewelry compiler and rule corpus

paracraft compounds through:

- jewelry-specific parametric modules
- bounded, composable controls
- openscad compilation patterns
- alloy and process shrinkage rules
- wall, feature, clearance, cavity, and envelope constraints
- deterministic fixtures and regression tests
- mappings between a design rule and the partners able to satisfy it

competitors can use openscad. copying years of tested jewelry-domain behavior, failure cases, and release compatibility is harder.

## 2. the intent-to-parameter language

tessa becomes more useful as sculptura develops a structured vocabulary linking natural descriptions and visual relationships to safe paracraft controls.

this is not a dataset of arbitrary generated meshes. it is a governed mapping between creator intent, accepted parameter changes, rejected suggestions, final released designs, and manufacturing outcomes.

## 3. manufacturing capability graph

supplier directories are easy to copy. a maintained graph of what each partner can actually cast, under which constraints, at what quality, through which integration, in which route, with which hallmarking and delivery evidence is not.

capabilities become stronger through quote accuracy, acceptance rate, defect rate, rework, lead time, route performance, and exception history.

## 4. release-to-outcome data

every fulfilled order can connect:

```text
creator intent
→ accepted parameters
→ compiler and rule versions
→ geometry and mass
→ quote and route
→ production outcome
→ quality and delivery outcome
```

that lineage can improve rules, quoting, partner selection, and creator guidance. the value comes from structured causal records, not a vague pile of marketplace data.

## 5. compliance and route graph

localized tax, customs, hallmarking, carrier, insurance, and consumer obligations create a changing route graph. sculptura's defensibility grows when those requirements are versioned, evidenced, and enforced as software predicates rather than rediscovered manually for each order.

this includes modeling applicable eu oss workflows and precious-metal hallmarking treaties without assuming either creates universal coverage.

## 6. integration and reconciliation depth

placing one factory order through an api is easy. reliably handling quote expiry, upload integrity, retries, status mismatch, cancellations, tracking, defects, refunds, and payout consequences across several partners is not.

adapter depth and operational reconciliation become switching costs for both the platform and participating casters.

## 7. creator catalog and distribution

creators accumulate:

- released designs
- storefront identity
- followers and collections
- conversion and fit knowledge
- customer trust
- channel connections
- ordinary sales and optional commission reputation

because the design release can power shared, white-label, and connected channels, creators are not trapped inside one discovery feed. sculptura remains valuable as the production and fulfillment source of truth.

## 8. trust

jewelry is high-consideration and emotionally loaded. deterministic previews, exact release versioning, transparent materials, predictable manufacturing, route-aware compliance, delivery visibility, and fair dispute handling create trust that a generic prompt-to-mesh tool cannot claim.

## what is not a moat

- saying “ai-powered”
- calling a generic model api
- a public manufacturer list
- a storefront theme
- hardcoded material prices
- one sculpteo submission form
- a universal admin password
- a large volume of unstructured images

## the compounding loop

```text
more creators and releases
→ more manufacturing attempts
→ better rule and quote calibration
→ fewer failures and better routes
→ higher trust and conversion
→ more creators and partners
```

the loop becomes defensible only when outcomes are measured and fed back into versioned rules. scale without that discipline is merely more operational risk.
