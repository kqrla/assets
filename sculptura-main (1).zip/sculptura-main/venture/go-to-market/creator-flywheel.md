# creator and distribution flywheel

## start with latent creators

sculptura's initial supply is not limited to trained jewelry designers. the strongest early users may be people who already publish or curate visual taste:

- digital illustrators
- avatar and game-asset designers
- 2d concept artists
- fashion and interior creators
- pinterest and mood-board curators
- niche community tastemakers
- couples and gift-givers who discover they want to author a piece

product onboarding should make the identity shift explicit: “you already have the taste; now you can become the creator.”

## activation sequence

1. creator identity
2. first private project
3. first successful paracraft compile
4. first manufacturability pass
5. first design release
6. first ordinary listing
7. first paid and fulfilled order
8. optional commission toggle
9. additional storefront or connected channel

commission requests should not be used to hide a weak ordinary listing loop. passive made-to-order offers prove that released designs can repeatedly sell and fulfill.

## why commissions come later

commissions increase value and creator-buyer intimacy, but they also introduce conversation, scope, revisions, payment protection, acceptance, cancellation, and disputes. activating them after a creator understands the studio and has released work improves quality and gives commissioners evidence of the creator's style.

creators can pause commissions during high demand without losing their catalog or ordinary sales.

## demand loops

### shared marketplace

published releases create discovery, collections, follows, and social proof.

### creator storefronts

creators bring existing audiences to branded catalogs without building manufacturing operations.

### white-label and connected channels

external channels expand demand while sculptura retains release, pricing, production, and fulfillment truth.

### shareable creation stories

mood board to parameters to webgl model to cast metal is itself compelling content. process visibility can help creators market both the piece and their authorship.

## partner flywheel

more validated demand can make sculptura attractive to casting partners because it reduces poor-file intake and consumer support. more approved partners can improve route coverage, quote competition, delivery time, and resilience. better fulfillment improves creator trust and demand.

## metrics that matter

- creator project to first compile rate
- first compile to first valid release rate
- release to listing rate
- listing to first order time
- quote accuracy and expiry loss
- production acceptance and defect rates
- delivery success and lead time
- creator earnings and repeat release rate
- buyer repeat purchase rate
- commission toggle, acceptance, completion, and dispute rates
- contribution margin after defects, refunds, support, and reserves

vanity signup counts are not the flywheel. released, purchased, successfully manufactured pieces are.
