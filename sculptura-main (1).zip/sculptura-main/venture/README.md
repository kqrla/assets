# venture

## what this is

sculptura makes custom metal-jewelry manufacturing less hostile to people who have taste but do not know cad.

people already know what they want a piece to feel like. they collect references, save pinterest boards, sketch forms, and describe textures. today, turning that taste into a manufacturable ring or pendant means running into rhino or matrixgold, casting tolerances, alloy shrinkage, local foundries, quote requests, file failures, emails, whatsapp threads, payment logistics, and fulfillment.

much of that friction is repetitive data translation:

- a ring size maps to an inner diameter
- a precious-metal alloy has a measurable shrinkage allowance
- an investment-casting process requires minimum walls and features
- a model has calculable volume and mass
- a caster prices work from geometry, material, process, finishing, and route
- a destination changes tax, hallmarking, shipping, and compliance requirements

those relationships are geometric, physical, regulatory, and financial. computers are good at relationships. sculptura automates the rigid work so creators can focus on taste.

## the operating thesis

we do not hire bench jewelers, and we hold zero physical gold inventory. we build the digital glue.

sculptura turns manufacturing constraints into software rules, creators' intent into deterministic openscad geometry, released geometry into sellable offers, and paid orders into locally eligible production routes. distributed casting partners retain the machinery, metal procurement, casting operations, finishing labor, and physical fulfillment.

this is not a plan to reinvent jewelry cad, payment networks, casting, shipping, or tax infrastructure. it is an orchestration and domain-logic company built on proven rails:

- tessa translates human intent into approved parameters
- paracraft compiles those parameters deterministically through openscad
- webgl renders the compiled model in the creator's browser
- payment providers handle regulated money movement and connected accounts
- existing casting houses print, cast, finish, and ship
- sculptura owns the contracts, safety rules, release integrity, pricing logic, compliance-aware routing, and end-to-end state

## permanent and provisional boundaries

- sculptura is permanently metal-only and never holds or supplies stones
- supporting an empty bezel or prepared setting for a buyer-provided future stone remains provisional
- creators operate the studio; buyers who want to design become creators
- ordinary made-to-order listings come first
- commissions are an optional later creator toggle
- tessa never generates production geometry
- paracraft is the geometric and physical-rule authority

## venture map

- [`thesis/problem-and-wedge.md`](thesis/problem-and-wedge.md): why the problem exists and where sculptura enters
- [`product/five-perspectives.md`](product/five-perspectives.md): the system as seen by each participant
- [`architecture/digital-glue.md`](architecture/digital-glue.md): what is reused, what sculptura owns, and how the rails connect
- [`moat/defensibility.md`](moat/defensibility.md): compounding technical, data, operational, and distribution advantages
- [`economics/asset-light-model.md`](economics/asset-light-model.md): inventory profile, unit economics, working capital, and payment rails
- [`../operations/financial/mock-finance-flow.md`](../operations/financial/mock-finance-flow.md): spree and mock payments prototype, distinct from live finance
- [`go-to-market/creator-flywheel.md`](go-to-market/creator-flywheel.md): latent creators, ordinary listings, commissions, and channel expansion
- [`risks/proof-plan.md`](risks/proof-plan.md): claims that must be demonstrated before they are used as investor facts

## concise positioning

sculptura is creator infrastructure for deterministic, manufacturable, made-to-order metal jewelry. it lets people monetize taste without first becoming cad technicians, manufacturing operators, inventory buyers, or logistics teams.
