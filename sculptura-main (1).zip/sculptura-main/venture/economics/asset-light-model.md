# asset-light economics

## the low-asset operating model

sculptura does not hire a distributed bench-jeweler workforce, buy casting machinery, or hold physical gold, silver, brass, or bronze inventory.

approved manufacturing partners absorb the physical capital requirements:

- printers and castable pattern processes
- investment, burnout, and casting equipment
- precious-metal procurement
- specialist production labor
- finishing equipment
- local packing and dispatch

sculptura's inventory is digital: projects, design releases, listings, rules, capability records, and operational state. the marginal storage and compilation cost of another released design is low compared with holding another physical jewelry sku.

## what zero inventory does and does not mean

zero physical inventory removes metal-price exposure on unsold stock, warehouse carrying costs, dead sizes, and forecast risk. it does not remove:

- cloud and model-inference costs
- failed-production and remake exposure
- payment fees and chargebacks
- refunds and consumer-law obligations
- customer-support costs
- temporary working-capital gaps
- insurance and claims
- reserves required by payment providers
- integration and compliance maintenance

an asset-light company can still have cash-flow and liability risk. those risks must be priced and reserved rather than hidden behind payment-provider language.

## revenue structure

possible revenue components include:

- a platform take rate on each completed sale
- payment or operational fees presented transparently where permitted
- creator subscription tiers for advanced studio, channels, analytics, or capacity
- commission-service fees when the protected lifecycle exists
- enterprise or white-label infrastructure fees

manufacturing cost, tax, delivery, insurance, refunds, and creator earnings are not platform revenue merely because funds pass through the system.

## why average order value matters

made-to-order metal jewelry can support higher order values than commodity print-on-demand categories such as stickers or basic apparel. this creates room to pay for:

- more rigorous design validation
- insured fulfillment
- human support for exceptions
- partner-quality controls
- creator earnings
- payment and compliance overhead

high order value also increases dispute, fraud, remake, and trust stakes. it is an advantage only if failure rates remain controlled.

## simplified unit economics

```text
customer charge
- tax collected for authorities
- payment processing
- manufacturing quote
- finishing and hallmarking
- shipping and insurance
- expected refund, defect, and chargeback reserve
- creator earnings
= sculptura gross contribution
```

creator pricing remains two-way:

- fix desired creator earnings and calculate the required retail price
- fix retail price and calculate the resulting creator earnings

both modes must use the same trusted route and cost snapshot.

## payment architecture

stripe connect is the intended first creator-payout rail. the exact charge and transfer model must be selected based on merchant-of-record responsibilities, refunds, disputes, connected-account geography, reserves, and control requirements.

single-use virtual cards for exact factory costs are a possible factory-payment mechanism when provider availability and caster acceptance make them sensible. they are not required for the core thesis. direct api payment, invoice settlement, prefunding, or another controlled commercial-payment method may be better for a given partner.

## capital efficiency thesis

sculptura can scale design supply and transaction volume without buying metal inventory or factories. capital instead funds:

- product and compiler development
- manufacturing and compliance integrations
- trust, safety, and support
- partner onboarding and quality systems
- creator acquisition
- reserves and working capital appropriate to payment and fulfillment risk

this is low-asset, not no-cost.
