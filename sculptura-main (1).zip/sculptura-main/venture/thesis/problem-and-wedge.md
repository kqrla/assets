# problem and wedge

## the blocked creator

there is a large group of people with visual judgment but no practical route into physical jewelry. they include digital illustrators, avatar designers, fashion and interior enthusiasts, pinterest lurkers, 2d concept artists, gift-givers, couples imagining wedding bands, and people who constantly think, “this would look better if...”

the idea of becoming a jewelry creator often never occurs to them. entry appears to require:

- years of specialist cad learning
- expensive jewelry-design software
- knowledge of alloy behavior and casting tolerances
- foundry relationships
- prototype and sampling budgets
- precious-metal inventory
- photography and storefront setup
- fulfillment and customer support

sculptura's first wedge is not “better generative ai.” it is making the path from taste to safe parametric geometry understandable.

## why jewelry is unusually suitable

jewelry is emotionally expressive, but much of its production path is constrained and measurable.

| human intent | deterministic relationship |
|---|---|
| “comfortable inside” | inner profile, edge radius, surface exclusions |
| ring size | inner diameter and circumference |
| “chunkier” | bounded width, thickness, and mass changes |
| alloy choice | density, shrinkage allowance, casting constraints |
| repeated texture | frequency, amplitude, spacing, and exclusions |
| manufacturing viability | walls, gaps, features, cavities, envelope, process rules |
| production cost | volume, mass, material, finishing, partner, and route |

tessa handles the translation from the left column to proposed values on the right. paracraft determines whether those values can become physical geometry.

## the initial product loop

1. a person becomes a creator
2. the creator supplies references and intent
3. tessa proposes constrained parameter changes
4. the creator directs the result
5. paracraft compiles openscad and enforces physical rules
6. webgl shows the deterministic model in the browser
7. a passing build becomes a versioned design release
8. the creator publishes an ordinary made-to-order listing
9. a paid order is routed to an eligible caster
10. the caster produces and ships the metal piece

## expansion without changing the core

once ordinary listings work, a creator may toggle commissions on. commissions add authenticated briefs, conversation, payment protection, revisions, acceptance, and disputes. they do not change who operates the studio or how geometry reaches production.

white-label storefronts and connected channels extend distribution while sculptura remains the source of truth for the release, pricing snapshot, route, and fulfillment state.

## why now

- browser graphics can deliver accessible interactive model review
- openscad provides proven deterministic geometric rails
- vision models can interpret references without being trusted to generate production geometry
- connected-account payment infrastructure can support creator marketplaces
- distributed casting services already own the physical machinery and specialist labor
- apis and controlled operational adapters can connect fragmented steps that previously lived in email and spreadsheets

sculptura's opportunity is to make those existing capabilities behave like one coherent product.
