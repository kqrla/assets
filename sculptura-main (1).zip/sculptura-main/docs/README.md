# project documentation

- [`current-state-audit.md`](current-state-audit.md) records what exists across all supplied source files, what belongs in each domain, and the ordered build plan
- [`architecture/`](architecture/README.md) defines the target system boundaries and end-to-end flow
- [`../audit/index.md`](../audit/index.md) tracks every supplied source file and separates implementation states
- [`../operations/financial/mock-finance-flow.md`](../operations/financial/mock-finance-flow.md) drafts the local finance prototype

the one-shot explanation is [`explain.md`](../explain.md); detailed explanations live under [`explain/`](../explain/index.md). changing implementation status requires updating the relevant domain readme and the current-state audit together.
