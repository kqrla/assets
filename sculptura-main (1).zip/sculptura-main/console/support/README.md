# console: support

case presentation and communication for order, delivery, payment, and claim problems. support actions call the owning operations workflow instead of directly rewriting financial or shipping state.

## audited implementation reference

**status: missing**

### existing source evidence

- no ticket, conversation, case, service-level, claim, or support-assignment implementation was found.

### what exists now

- the product has messages and explanatory pages, but no support system.

### required changes

- create support cases linked to buyer, creator, order, production, delivery, refund, and commission records.
- add ownership, priority, timelines, evidence, escalation, and audit history.

see the [complete source audit](../../docs/current-state-audit.md) for cross-domain findings and build order.
