# publish and buy

1. creator chooses a passed design release
2. platform creates or updates a listing that references the release id
3. console calculates regional retail and creator earnings snapshots
4. listing becomes available on sculptura and enabled external channels
5. buyer selects metal, size, quantity, and destination
6. checkout requests a fresh console quote and snapshots it server-side
7. buyer pays without needing an account
8. paid order is handed to admin routing

browser-submitted prices are never authoritative.