# platform shells

shells preserve interface work that is intentionally not connected to an incomplete or unsafe product lifecycle.

## current contents

- [`commissions-muted`](commissions-muted/README.md) keeps the creator commission-management surface visible without pretending authenticated intake, escrow, approval, fulfillment, and disputes are ready.

shells must not write production records, expose private data, or bypass feature gates.
