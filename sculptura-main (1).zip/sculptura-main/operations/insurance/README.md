# insurance

coverage eligibility, declared value, carrier/manufacturer exclusions, claim windows, evidence, decisions, and recovery. insurance support is country-, carrier-, route-, and value-dependent.

## audited implementation reference

**status: missing**

### existing source evidence

- no policy, coverage, declared value, premium, exclusion, claim, or recovery records were found.

### what exists now

- insurance is mentioned only as intended behavior.

### required changes

- model route-specific coverage, declared value, evidence, claim windows, filing, decision, reimbursement, and exclusions.

see the [complete source audit](../../docs/current-state-audit.md) for cross-domain findings and build order.
