# legal

terms, creator and buyer agreements, intellectual-property process, commission terms, prohibited use, dispute policy, and jurisdiction-specific obligations. this folder records product requirements and counsel-reviewed decisions, not invented legal conclusions.

the creator intellectual-property research lives in [creator-ip/](creator-ip/README.md): the ownership stack from bases and parameter states to compiled meshes and capture assets, and the open questions around authorship, commissions, licenses, and enforcement.

## audited implementation reference

**status: partial content only**

### existing source evidence

- [`sculptura.dev/src/components/commissions/CommissionTermsEditor.jsx`](../../what-exists/lovable/src/components/commissions/CommissionTermsEditor.jsx)
- store faq and content fields
- static informational pages

### what exists now

- creators can edit commission wording, but there is no versioned acceptance record or jurisdiction-aware terms system.

### required changes

- version platform, purchase, privacy, creator, commission, and manufacturing terms.
- record the exact accepted version and evidence.
- keep legal review distinct from editable storefront copy.

see the [complete source audit](../../docs/current-state-audit.md) for cross-domain findings and build order.
