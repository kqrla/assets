# creator journey

## the problem

many people have a clear sense of what they like before they think of themselves as creators. they save jewelry references, collect images on pinterest, notice unusual forms, combine details from different pieces, and imagine something they cannot find in a shop.

for most of them, the idea of becoming a jewelry designer never seriously occurs. the path appears to begin with expensive professional cad software, a steep technical learning curve, knowledge of casting and precious metals, prototype costs, supplier relationships, inventory risk, photography, selling, shipping, and customer support. even imagining the role can feel out of scope.

that means a large amount of creative taste never becomes creative output. the barrier is not necessarily a lack of ideas. it is the cost and complexity between an idea and a finished, sellable piece.

sculptura exists to patch that gap.

it gives a person a path from visual intent to a controlled jewelry design, then connects that design to validation, offering, made-to-order manufacturing, and delivery. the creator does not need to become a conventional cad operator, buy precious metal, fund inventory, own a workshop, or personally fulfill every order before they can discover whether people want their work.

sculptura is not trying to replace taste or authorship. the creator decides what the piece should be. the system makes those decisions expressible, reproducible, manufacturable, and operable.

---

## who uses it

### creators

creators operate the design studio. they bring the idea, references, judgment, and final decisions. they adjust proportions and details, review the three-dimensional result, respond to manufacturing checks, and decide when a design is ready to release.

an approved design can be offered through the shared sculptura marketplace, a sculptura creator storefront, a white-label storefront, or a connected channel such as shopify. sculptura remains the source of truth for the production release and fulfillment state even when another channel produced the sale.

creating a creator account does not automatically place someone on the homepage. discovery begins with published work and can later use explicit eligibility, relevance, quality, curation, and performance rules.

### buyers

buyers browse released designs, choose an available material and size, and place an order. an ordinary print-on-demand purchase does not require a buyer account.

if a buyer realizes they want to author a new piece rather than purchase an existing release, sculptura moves them into creator onboarding. they become the creator of a private project and use the studio under that identity. this is how a passive buyer becomes an active co-designer without giving anonymous checkout direct access to tessa or paracraft.

checkout must re-establish the current production route and trusted price on the server. it cannot trust manufacturing costs, creator earnings, validation claims, or totals supplied by the browser.

### commissioners

commissioners are buyers who ask a creator to develop something specifically for them. they provide references, measurements, preferences, a budget, and a brief. the creator interprets that material and uses the studio to make the design.

commissioners require accounts. a commission is not a guest form submission. it needs a persistent creator relationship, conversation history, revisions, approvals, payment protection, cancellation rules, delivery of the agreed result, and a dispute path.

buyers and commissioners do not operate the studio assistant or geometry engine directly. the creator remains responsible for interpreting the brief and authoring the piece.
