# a closer look at sculptura

[`../explain.md`](../explain.md) is the one-shot explanation. the sections here give the details behind it:

- [creator experience](creator-experience/overview.md): the idea, the people, and the creator journey
- [studio](studio/overview.md): tessa, paracraft, server validation, and design releases
- [platform](platform/overview.md): listings, storefronts, pricing, purchases, and optional commissions
- [manufacturing](manufacturing/overview.md): partner selection, casting, materials, and hallmarking
- [operations](operations/overview.md): rollout, payments, support, and admin controls
- [worked example](example/overview.md): one design through purchase and delivery

these describe the intended product. for evidence about what the current sources actually implement, see [the file-by-file audit](../audit/index.md).
