# making and delivering the jewelry

## what happens after a purchase

once payment reaches the required state, operations finds an eligible manufacturing route.

it removes any partner that cannot make the selected material, cannot satisfy the release constraints, cannot serve the destination, lacks the required hallmarking or documentation path, has not completed operational onboarding, or is unavailable.

remaining routes can be compared using:

- complete manufacturing cost
- manufacturing and delivery time
- distance from the customer
- duties, customs, vat, and tariff exposure
- finishing capability
- reliability and recent performance
- insurance and claim limits
- likely return and delivery complications

nearest is not always best. the lowest quoted part can become the most expensive complete route after shipping, customs, failure risk, and rework. routing selects the best approved complete path, not merely the first partner in a list.

---

## how the jewelry is produced

launch scope is made-to-order metal jewelry.

for a typical cast piece, the selected partner receives the exact approved model and production instructions. the partner produces a castable resin or wax pattern, invests it, removes the pattern through burnout, casts the selected metal into the cavity, cleans and finishes the piece, and ships it with the required records.

not every three-dimensional printing business can perform this workflow. plastic prototyping and direct industrial metal printing do not prove precious-metal jewelry casting capability. every manufacturer record therefore needs evidence for its processes, materials, limits, ordering method, service regions, finishing, hallmarking path, and commercial readiness.

partners do not need a sculptura-facing portal. sculptura connects outward through an approved adapter. that may use a public application programming interface, a private commercial integration, or a controlled manual process for a specialist regional casting house.

---

## materials, stones, and hallmarking

metal-only jewelry is a permanent product boundary. sculptura does not supply, sell, source, inventory, grade, insure, or fulfill gemstones.

whether a later release may support an empty bezel or prepared setting for a buyer-provided future stone is deliberately left open. that is a sand-drawn product line, not a promise. supporting it would require separate measurement tolerances, liability, intake, shipping, setting, and manufacturer rules, while sculptura itself would remain metal-only.

precious-metal products can require fineness testing, assay-office involvement, responsibility marks, a common control mark, importer records, and destination-specific consumer information. route eligibility therefore includes hallmarking and precious-metal compliance. no single mark or country grouping is assumed to solve every route.
