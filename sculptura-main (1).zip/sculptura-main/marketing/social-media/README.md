# social-media

placeholder for social content planning: post series, launch announcements, and platform-specific voice notes.

## status

not started. no calendar, no channel accounts, no drafted posts. this folder exists to hold that work once it begins, kept separate from the content shell and the product itself so posting cadence never becomes a product dependency.
