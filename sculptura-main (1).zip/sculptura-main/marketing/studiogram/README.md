# studiogram, re-explained

the public-facing version of [studio/studiogram/](../../studio/studiogram/README.md). same concept, written for the content shell instead of the internal build docs.

## photograph jewelry before it has been made

studiogram is sculptura's virtual product studio. a creator finishes a design, and the same exact 3d object that will be sent for manufacturing is placed on a configurable hand, posed, lit, and photographed. no sample, no model, no camera, no shoot.

because the photograph is a rendering of the real compiled design, the image and the product can never drift apart. the capture set exports as clean png images ready for a product carousel, and the saved scene can recreate any view later.

## how it reads to a visitor

- **prepare the subject:** pick a hand, add the jewelry, place it
- **direct the scene:** pose, camera, light, backdrop
- **capture the set:** save a few views, export a carousel

the full guide-by-guide breakdown (why it exists, how it works, the hand, the jewelry, the scene system, capture, behind the scenes) lives in [studio/studiogram/](../../studio/studiogram/README.md); this page stays the short public version.

## similar and reference

- [ijewel.design](https://ijewel.design): a 3d jewelry showcase platform for designers, upload-to-showcase with material configurators. studiogram differs by never accepting uploads: it photographs the same compiled artifact that would be manufactured, not a separate copy. full comparison in [studio/studiogram/references.md](../../studio/studiogram/references.md).

## future version

- [wearables/](wearables/README.md): vr and ar try-on built on the same idea, one step further
