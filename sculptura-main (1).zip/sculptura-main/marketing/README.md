# marketing

outward-facing re-explanations of the concepts documented elsewhere in this repository. the technical truth lives in the domain folders (studio, manufacturing); this folder translates it into the language a public site can use.

## subfolders

- [brand/](brand/README.md): visual identity, starting with the wordmark
- [positioning/](positioning/README.md): the pitch, real metal not props, designers-anywhere routing
- [social-media/](social-media/README.md): social content planning, not started
- [studiogram/](studiogram/README.md): the public version of the virtual product studio, with [wearables/](studiogram/wearables/README.md) nested inside it as the future vr/ar try-on version

## boundary

this folder feeds the [content shell](../buildplan/scoping.md), the static explanatory site: no accounts, no orders, no database. it does not itself become the site; a separate build consumes this content.
