# positioning

the pitch, in the words a public site can use. the technical truth lives in the domain folders; this page translates it.

## the pitch

sculptura: a path from a jewelry idea to a manufacturable, sellable, made-to-order piece, without requiring a workshop, inventory, or years of cad training.

## real metal, not props

every artifact is cast in solid silver, brass, bronze, or gold using lost wax casting from a 3d printed pattern: the same technique goldsmiths have used for thousands of years, modernized with 3d printing on the front end. for larger sculptural pieces, sand casting from the same printed pattern keeps big pours affordable.

direct metal printing exists, but for wearable pieces at indie volumes, investment casting wins on price, finish, and metal selection. the process explanations live in [manufacturing/processes/](../../manufacturing/processes/README.md).

## designers anywhere, manufacturing anywhere

creators are not limited to sculptura's marketplace. they can white-label their storefront or connect channels such as shopify, and orders route to the most suitable regional casting partner based on geography, capabilities, cost, and import exposure. the platform handles the behind-the-scenes manufacturing end to end: printing a castable pattern, casting, finishing, and shipping, with no cad skills, materials, inventory, or forge required.

## voice rules

lowercase throughout, no emojis, no em dashes. proper nouns may be lowercase too. keep exact case only where it would break something: code, urls, external names.
