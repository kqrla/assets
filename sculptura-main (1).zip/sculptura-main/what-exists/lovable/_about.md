# about this import: lovable (`sculptura.dev`)

this folder is an imported, frozen snapshot of the `sculptura.dev` source repository: the lovable-built attempt at the public site and platform, the one whose conjoining of content and commerce is recorded as the first fault in [buildplan/scoping.md](../../buildplan/scoping.md).

imported 2026-09-24. node_modules, dist, and .git history were stripped; everything else was kept as delivered, including this folder's own `README.md`, `AGENTS.md`, and doc files (`research.md`, `roadmap.md`, `techstack.md`, `theme.md`, `underthehood.md`, `port.md`, `portsb.md`, `features.md`), which describe the source project from inside itself and are not this foundation's voice. `.lovable/` holds that build tool's own planning notes, including the studiogram content plan already absorbed into [studio/studiogram/](../../studio/studiogram/README.md).

see [what-exists/](../README.md) for the import rules, and [audit/studio.md](../../audit/studio.md), [audit/platform.md](../../audit/platform.md), and [audit/operations.md](../../audit/operations.md) for what was actually assessed here.
