# about this import: base44 (`sculptura`)

this folder is an imported, frozen snapshot of the `sculptura` source repository: the base44-built attempt at the platform. it is cited throughout this repository's domain readmes and the [audit](../../audit/index.md) as evidence of what exists.

imported 2026-09-24. node_modules, dist, and .git history were stripped; everything else was kept as delivered, including this folder's own `README.md` and doc files (`src/roadmap.md`, `src/techstack.md`, and the rest), which describe the source project from inside itself and are not this foundation's voice.

see [what-exists/](../README.md) for the import rules, and [audit/studio.md](../../audit/studio.md), [audit/platform.md](../../audit/platform.md), and [audit/operations.md](../../audit/operations.md) for what was actually assessed here.
