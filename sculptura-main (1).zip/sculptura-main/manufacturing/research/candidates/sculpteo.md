# sculpteo

status: drafted

## finding

sculpteo explicitly offers lost-wax casting from a 3d-printed wax model in bronze, brass, and silver, including jewelry applications. its public web api documents upload, material query, quoting, order creation, and status tracking. quoting is self-serve; production ordering is not fully self-serve because invoice payment must be enabled manually on the account first.

## conditions and caveats

- the reviewed first-party pages do not verify gold casting, so gold is not recorded as supported
- exact minimum wall thickness, feature size, tolerance, and maximum part dimensions remain null until a sculpteo-specific source establishes them
- stone setting and bring-your-own-stone support remain unknown
- an api sandbox/docs page proves an interface exists, not that production credentials have been approved for sculptura

## sources

- [metal 3d printing service](https://www.sculpteo.com/en/services/metal-3d-printing-service): establishes printed-wax lost-wax casting in bronze, brass, and silver for jewelry (retrieved 2026-09-22)
- [sculpteo api services](https://www.sculpteo.com/en/services/api-services): establishes public integration support for upload, configuration, quotation, ordering, and tracking (retrieved 2026-09-22)
- [ordering designs via api](https://www.sculpteo.com/en/developer/webapi/order/order): establishes the production order endpoint and the manual invoice-payment enablement prerequisite (retrieved 2026-09-22)
- [webapi documentation](https://www.sculpteo.com/en/developer/webapi): establishes the developer documentation root and endpoint families (retrieved 2026-09-22)

## how this enters the engine

sculpteo may be a drafted silver/brass/bronze route, but remains excluded from accepted production routing until account onboarding and a real representative quote are completed.
