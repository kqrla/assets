# xometry

status: drafted

## finding

xometry documents investment casting as a supported manufacturing process and provides online cad upload and quoting. the reviewed sources do **not** establish that xometry itself offers the required printed-pattern-to-precious-metal jewelry casting route, so process fit remains unknown rather than being inferred from a general article saying investment casting is used in jewelry.

## conditions and caveats

- no reviewed source names gold, silver, platinum, or another precious metal as an available xometry investment-casting material
- no reviewed source proves that the investment-casting route starts from a printed castable resin or wax pattern
- online quoting is documented, but a public api for this specific production route is not
- this candidate cannot enter automatic routing while process fit is unknown

## sources

- [investment casting: definition, how it works, advantages, and examples](https://www.xometry.com/resources/casting/investment-casting): establishes that xometry documents the investment-casting process and lists jewelry as one application; it does not establish a precious-metal jewelry service (retrieved 2026-09-22)
- [request a quote with xometry](https://xometry.com/how-xometry-works/request-a-quote): establishes cad upload and online/manual quote flows (retrieved 2026-09-22)
- [get started with xometry](https://www.xometry.com/get-started): establishes the general upload, quote, production, and shipping flow (retrieved 2026-09-22)

## how this enters the engine

it does not enter the routing set until a first-party material/process source confirms precious-metal lost-wax casting from a printed pattern.
