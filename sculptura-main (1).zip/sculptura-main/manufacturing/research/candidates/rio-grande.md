# rio grande

status: drafted

## finding

rio grande supplies wax and casting materials suitable for investment casting and offers customization services with file submission and quoting, but there is no explicit confirmation that they perform precious-metal jewelry casting from printed castable resin or wax patterns.

## conditions and caveats

- no direct evidence that rio grande performs lost-wax casting from printed castable resin or wax patterns; only supplies and customization services are documented.
- no information on minimum wall thickness, feature size, or tolerances specific to their casting process.
- api capabilities and file requirements are not documented.

## sources

- [jewelry mold & model making supplies | rtv, wax & casting](https://www.riogrande.com/category/tools-and-equipment/mold--model-making): rio grande offers wax and casting materials for jewelry mold and model making, indicating support for investment casting supplies. (retrieved 2026-09-22)
- [customization services](https://www.riogrande.com/services/customization): rio grande provides customization services with file submission and quoting, with a minimum order of $5,000. (retrieved 2026-09-22)

## how this enters the engine

rio grande is recorded as a supplier of wax and casting materials and a provider of customization services without confirmed direct precious-metal lost-wax casting from printed patterns.
