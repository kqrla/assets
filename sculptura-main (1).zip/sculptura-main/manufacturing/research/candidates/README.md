# manufacturer candidate assessments

one file records each researched candidate. assessments must distinguish precious-metal lost-wax or investment casting from unrelated printing services, and must separate evidence of capability from evidence of a production-ready integration.

none of these files activates a partner. approval requires reviewed capability data, commercial onboarding, credential and adapter setup, a usable quote and order path, service-region confirmation, quality expectations, and operational ownership.
