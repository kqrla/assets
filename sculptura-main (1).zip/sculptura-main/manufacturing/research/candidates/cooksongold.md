# cooksongold

status: drafted

## finding

cooksongold offers a precious metal casting service using 3d printed wax patterns followed by investment (lost wax) casting. they support multiple precious metals including recycled gold and silver, provide polishing and hallmarking, and have detailed design guidelines specifying minimum wall thickness around 0.5-0.8mm and maximum part size about 30x50x70mm. the process is manual quote based with typical turnaround of 10 working days. they are part of the heimerle + meule group and serve customers worldwide.

## conditions and caveats

- no explicit public api or self-serve api endpoints documented.
- stone setting services and byo stone support are not explicitly mentioned and remain unknown.
- tolerance values are not precisely specified by cooksongold; typical tolerances are null.
- file requirements and accepted formats are detailed but no direct upload api endpoints are confirmed.
- maximum part size differs slightly between sources; cooksongold states 30x50x70mm, materialise states 88x88x125mm for gold lost wax casting.

## sources

- [precious metal casting design guidelines](https://www.cooksongold.com/precious-metal-casting/design-guidelines): confirms use of 3d printed wax patterns for lost wax casting in precious metals including gold and silver, minimum wall thickness advice (0.5-0.8mm), maximum part size (30x50x70mm), file requirements (watertight, manifold, no sprues), and polishing/finishing details. (retrieved 2026-09-22)
- [precious metal casting | cooksongold](https://cooksongold.com/precious-metal-casting): describes the process: cad design uploaded, 3d printed wax model, tree casting method, investment casting with precious metals including recycled gold and silver, polishing and hallmarking services, and typical turnaround of 10 working days. (retrieved 2026-09-22)
- [about us - cooksongold additive manufacturing](https://www.cooksongold-am.com/about-us): establishes cooksongold as part of heimerle + meule group, a major european precious metals processor with operations in multiple countries. (retrieved 2026-09-22)
- [customisation services | personalise your designs at cooksongold](https://www.cooksongold.com/customisation): confirms customisation services including precious metal casting from uploaded or library designs, use of 100% recycled gold and silver, and online ordering portals. (retrieved 2026-09-22)
- [design guidelines for gold | lost-wax casting - materialise](https://www.materialise.com/en/academy/industrial/design-am/gold): provides detailed design guidelines for lost wax casting of gold from 3d printed wax patterns, including minimum wall thickness (0.8mm typical, 1mm for ring bands), minimum feature size (0.3-0.35mm), file formats accepted, and maximum part size (88x88x125mm). (retrieved 2026-09-22)
- [investment casting (lost wax): process, materials & applications](https://www.pahwametaltech.co.in/post/investment-casting-lost-wax-casting-complete-guide): describes investment casting (lost wax) process in detail, including typical minimum wall thickness (0.8-1.5mm), dimensional tolerances, and suitability for precious metals. confirms the process involves 3d printed wax patterns and ceramic shell investment. (retrieved 2026-09-22)

## how this enters the engine

cooksongold is included as a verified provider of precious metal lost wax casting from 3d printed wax patterns with detailed design guidelines and service descriptions.
