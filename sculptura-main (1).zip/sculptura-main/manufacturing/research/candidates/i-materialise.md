# i.materialise

status: drafted

## finding

i.materialise offers lost-wax casting services for precious metals such as gold and silver, with detailed design guidelines specifying minimum wall thickness and feature sizes suitable for jewelry. the maximum part size and tolerances are clearly stated, confirming support for the precious-metal lost-wax casting process.

## conditions and caveats

- none recorded

## sources

- [design guidelines for gold | lost-wax casting](https://www.materialise.com/en/academy/industrial/design-am/gold): technical specifications for gold lost-wax casting including minimum wall thickness 0.8 mm, minimum detail size 0.35 mm, max part size 88x88x125 mm. (retrieved 2026-09-22)
- [lost-wax casting (lwc) manufacturing services](https://www.materialise.com/en/industrial/3d-printing-technologies/lost-wax-casting): materialise offers lost-wax casting services in precious metals including gold and silver, with max build dimensions 88x88x125 mm, minimum wall thickness 0.6-0.8 mm, and standard accuracy ±5% with lower limit ±0.15 or ±0.35 mm. (retrieved 2026-09-22)

## how this enters the engine

confirmed i.materialise supports precious-metal jewelry manufacturing via printed castable resin/wax followed by lost-wax casting based on official materialise documentation.
