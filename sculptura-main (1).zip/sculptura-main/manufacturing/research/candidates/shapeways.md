# shapeways

status: drafted

## finding

shapeways offers lost wax casting services using 3d printed wax patterns for precious metals including gold, platinum, silver, and copper alloys. the process includes 3d printing wax patterns, investment casting, and post-processing. they provide a public api for developers, though details on endpoints and self-service are not fully documented. pricing is by manual quote.

## conditions and caveats

- minimum wall thickness and feature size are not explicitly stated in the sources.
- no explicit evidence on stone setting services or support for bring-your-own stones.
- api endpoint details and authentication methods are not fully detailed in the sources.
- regions served are not specified in the sources.

## sources

- [3d print lost wax casting - shapeways](https://www.shapeways.com/3d-print-material-technology/lost-wax-casting): shapeways offers lost wax casting using 3d printed wax patterns for precious metals including gold, platinum, silver, tin brass, tin bronze, and copper with specified bounding box sizes; the process includes 3d printing wax patterns, investment casting, and post-processing such as polishing and plating. (retrieved 2026-09-22)
- [3d print lost wax casting - shapeways](https://shapeways.com/3d-print-material-technology/wax-casting): confirms the use of 3d printed wax patterns for lost wax casting with precious metals and details on materials and bounding box sizes. (retrieved 2026-09-22)
- [3d print lost wax casting - material for 3d printing molds - shapeways](https://www.shapeways.com/blog/3d-print-lost-wax-casting-materials-molds): describes 3d printing of molds and wax patterns for lost wax casting, emphasizing the use of 3d printing to create wax patterns for investment casting of precious metals. (retrieved 2026-09-22)
- [shapeways provides api for developers](https://3druck.com/en/suppliers-distributors/shapeways-provides-api-for-developers-589336): shapeways offers a public api for developers with documentation at developers.shapeways.com. (retrieved 2026-09-22)

## how this enters the engine

shapeways is included as a provider of precious metal lost wax casting using 3d printed wax patterns with a public api and manual quoting.
