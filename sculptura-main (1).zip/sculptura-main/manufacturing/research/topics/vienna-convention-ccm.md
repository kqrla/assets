# vienna convention and the common control mark

status: open research task

## question

how does the convention on the control and marking of articles of precious metals, commonly called the vienna convention, affect sculptura's manufacturing routes, hallmarking evidence, and cross-border delivery?

the working hypothesis is that multiple target markets participate in or recognize systems connected to the common control mark (ccm). research must establish which ones before routing relies on it. where it applies, that may let an article tested and marked by an authorized assay office move across participating countries with less duplicate testing, but the exact effect must be verified per country, alloy, fineness, article type, weight exemption, and route.

## research outputs

1. current convention membership and accession status for every launch and research-hold country
2. whether the country recognizes the ccm and under which conditions
3. authorized assay offices relevant to candidate manufacturing routes
4. permitted fineness standards and required responsibility/sponsor marks
5. weight, article-type, and component exemptions
6. whether hallmarking must occur in the manufacturing country, destination country, or either
7. what production and assay evidence must travel with an order
8. whether direct-to-customer fulfillment changes importer or sponsor obligations
9. routing consequences when manufacturer, assay office, and buyer are in different countries
10. source date and official authority for every field

## initial target matrix

| country | rollout | convention/ccm status | domestic hallmarking interaction | routing consequence |
|---|---|---|---|---|
| united states | first cohort | research | research | research |
| canada | first cohort, high-ppp priority | research | research | research |
| united kingdom | first cohort | research | research | research |
| australia | first cohort, high-ppp priority | research | research | research |
| germany | first cohort | research | research | research |
| france | first cohort | research | research | research |
| italy | first cohort | research | research | research |
| netherlands | first cohort | research | research | research |
| spain | first cohort | research | research | research |
| belgium | first cohort | research | research | research |
| austria | first cohort | research | research | research |
| switzerland | first cohort, high-ppp priority | research | research | research |
| sweden | first cohort, high-ppp priority | research | research | research |
| denmark | first cohort, high-ppp priority | research | research | research |
| ireland | first cohort | research | research | research |
| new zealand | first cohort | research | research | research |
| japan | regional casting research hold | research | research | research |
| south korea | regional casting research hold | research | research | research |
| singapore | regional casting research hold | research | research | research |
| united arab emirates | regional casting research hold | research | research | research |
| norway | regional casting research hold, high-ppp priority, non-eu | research | research | research |
| israel | possible v3 candidate | research | research | research |

## citation rule

use official convention, national assay-office, customs, or government sources for legal status and marking requirements. trade summaries can locate a rule but cannot become the final authority. do not infer that convention membership removes every domestic hallmarking, importer, tax, or consumer-label obligation.

## engine and routing use

accepted findings become a versioned hallmarking-capability record consumed by manufacturing routing. a route is ineligible when it cannot produce the marks or evidence required for the destination and article.
