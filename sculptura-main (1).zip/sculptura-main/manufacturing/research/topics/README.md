# cross-cutting manufacturing research

this folder holds research that affects several partners or routes.

`vienna-convention-ccm.md` tracks the convention on the control and marking of articles of precious metals and common control mark questions for planned markets. it informs route compliance but does not replace destination-specific legal, hallmarking, assay, importer, and product review.
