# manufacturing research tasks

these documents are research and implementation work plans, not runtime features.

## application relationship

current applications have a sculpteo material list, a direct print handoff, manufacturer admin forms, and route-setting forms. they do not have verified adapters, live quotes, capability approval, route execution, or production reconciliation.

use the tasks here to close those evidence and integration gaps. completed research must be promoted through review into versioned capability data before routing can consume it.
