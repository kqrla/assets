# how studiogram works

step guide of the recovered studiogram guide. move from a compiled jewelry design to an ordered set of product images through one reproducible scene.

studiogram begins after the artifact has become a compiled mesh. a creator chooses a hand, arranges jewelry, directs the scene, and captures several views without creating a second version of the product.

## prepare the subject

choose a saved hand or shape a new one, then add one or more compiled artifacts. every piece attaches to a named location and remains an independent object in the scene.

- configure the hand
- add compiled artifacts
- place and stack pieces

## direct the scene

set the hand pose, camera framing, lighting, and environment. each control changes one part of the scene while preserving every other choice.

- pose the rig
- frame the camera
- shape light and backdrop

## capture the set

save a frame, adjust the scene, and save another. the resulting image set can be reviewed, ordered, and exported as png files for a product carousel.

- capture several views
- review the sequence
- export png images

back to the [studiogram guide](../README.md).
