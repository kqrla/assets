# add and arrange jewelry

step 02 of the recovered studiogram guide. bring the same modeled artifact used for manufacturing into the scene, then position and stack pieces without flattening them into an image.

studiogram uses the artifact's compiled 3d form. it does not redraw the piece for the photograph, so the object shown to a buyer remains tied to the design that would be manufactured.

## the real artifact enters the scene

the studio receives the same compiled artifact used by sculptura's viewer. information needed for placement travels with the design instead of being recreated after it reaches the studio.

- one artifact representation
- manufacturing and photography stay aligned
- placement information remains part of the design

## attach it to the hand

a piece is placed at a named location such as a finger, wrist, or earlobe. when the hand changes pose, the jewelry follows that location rather than staying frozen in space.

- finger, wrist, and earlobe placement
- position and orientation controls
- jewelry follows the hand's pose

## compose a stack

several pieces can share a scene. creators can reorder a stack, adjust supported positions, remove one piece, or combine available work from more than one creator while each artifact remains its own object.

- multiple independent pieces
- reorderable stacks
- support for available cross-creator artifacts

back to the [studiogram guide](../README.md).
