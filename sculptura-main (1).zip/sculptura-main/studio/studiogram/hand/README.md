# choose and shape a hand

step 01 of the recovered studiogram guide. start with one configurable hand model, then shape its proportions and surface without swapping it for a different person.

every variation begins with the same base hand. presentation, build, proportions, skin, nails, body hair, and tattoos are independent choices that can be saved together as a reusable hand configuration.

## one hand, many proportions

presentation and build are separate controls on one hand model. finer controls can shape hand width, finger length, finger thickness, and palm proportions. this keeps every setup flexible without maintaining a different hand model for every combination.

- neutral, masculine, and feminine presentation presets
- independent build and proportion controls
- one reusable base hand rather than a library of people

## surface details stay separate

skin tone, body hair, and nail appearance affect the surface rather than replacing the underlying hand. tattoos are placed on the skin and become part of its surface so they continue to move naturally when the hand is posed.

- skin tone and body hair controls
- nail length, shape, and appearance
- surface-aware tattoo placement

## save a hand once

a saved hand configuration keeps the complete set of shape and surface choices. a creator can maintain several configurations and reuse them across shoots while selecting jewelry separately for each scene.

- multiple saved configurations
- reusable across product shoots
- kept independent from jewelry arrangements

back to the [studiogram guide](../README.md).
