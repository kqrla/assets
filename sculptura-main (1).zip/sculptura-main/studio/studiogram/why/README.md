# why studiogram exists

step 00 of the recovered studiogram guide. close the photography gap between a finished digital design and the first physical casting.

made-to-order jewelry can be ready to validate and list before a physical sample exists. studiogram gives creators a way to present that exact design without first arranging casting, a model, a camera, and a physical shoot.

## photography normally comes last

traditional product photography begins after a piece has been manufactured. that makes every new listing depend on an upfront sample, even when the design is already complete and manufacturable as a digital object.

- no sample required before listing
- less upfront production
- earlier product presentation

## the design is already real

the artifact already has defined geometry, dimensions, materials, and manufacturing constraints. studiogram photographs that existing object rather than asking another system to invent an approximation of it.

- actual compiled geometry
- design and image stay aligned
- no imagined replacement

## creators keep control

the hand, jewelry arrangement, camera, light, and backdrop remain adjustable parts of a saved scene. creators direct the result and can return to the same setup whenever the listing changes.

- creator-directed scenes
- repeatable results
- reusable setups

back to the [studiogram guide](../README.md).
