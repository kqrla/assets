# capture and export the set

step 04 of the recovered studiogram guide. save several views from the same scene, review their order, and export a clean image set for a product carousel.

capture happens after the scene is composed. each shot records the current hand, jewelry, pose, camera, lighting, and backdrop, making the result repeatable rather than an isolated generated image.

## capture one composed frame

a capture records the current scene as one photograph. creators can then change the pose or camera and capture another view without rebuilding the hand or replacing the jewelry.

- one frame per capture
- same scene across alternate views
- repeatable from saved scene choices

## build a small photo set

a typical session can produce three or four complementary shots. these may show different angles, closer details, or a new pose while keeping the product consistent throughout.

- several related views
- consistent artifact geometry
- room for detail and context shots

## export for publishing

the finished set exports as png images intended for a carousel. attribution, captions, links, and posting remain with the creator on the platform where the images will be shared.

- png image set
- carousel-ready ordering
- creator-controlled publishing and attribution

back to the [studiogram guide](../README.md).
