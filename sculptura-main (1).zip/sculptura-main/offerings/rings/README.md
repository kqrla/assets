# rings

families from the audited browser prototype: flat or comfort bands, barrel, knife-edge, wave, twist, split, open, tapered, bypass, and signet. these are starting controls, not verified production presets. each release must bind profile, shank dimensions, interior comfort, ring-size system, relief and thickness limits, alloy, finishing method, and any required resizing restrictions.

[configure/rings](../configure/rings.md) adds creator-authored bases for affinity/connected forms, promise rings, double hearts and claddagh motifs. those describe meaning and allowable controls, not purchasable replicas or unbounded image-to-geometry generation. an occasion such as "promise" is not itself a manufacturable geometry.

engraving or embossing an initial may change depth, material mass and fragile features. a previously validated blank ring does not prove that arbitrary text is safe. use the [personalization gate](../configure/personalization.md). sizes, typography and variants cannot be asserted from this folder alone; the audited [release schema](../../contracts/design-release.schema.json) supports the `ring` type and a size array but not proof that all combinations have been validated.
