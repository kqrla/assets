# text, relief and symbolic details

options are more than a text box: a creator may approve placement, shape and relationship between elements within a defined base. separate inscription content from the relief geometry that the studio must produce and inspect.

- **text:** a single initial, paired initials, short name, date or approved phrase. define maximum glyph count by actual surface and font metrics, not a universal made-up limit. check supported script/font rights, kerning, orientation, spacing, legibility, privacy and offensive/third-party content rules.
- **engraving:** subtracts depth from an approved metal surface. keep remaining wall thickness, critical edge clearance and post-cast finishing in scope.
- **embossing:** adds raised relief with joining necks and surface blending. inspect protrusion, fragile tips, clipping, mass and wear points.
- **symbolic motifs:** creator-controlled heart, joined loop, hands/crown, engraved mark or pattern, each from a versioned primitive. no generated logo or borrowed brand artwork by default.
- **image relief:** historical jweel demonstrates it, but arbitrary image uploads are a separate research hold until rights checks, deterministic vectorization, feature filtering, production validation, and rejection behavior are implemented.

preview the selected option in the browser, but let the studio server independently build and validate the exact revision before it becomes a release or a unique order-specific artifact. record the accepted text and hash against the order privately where appropriate; a public product listing must not expose a buyer's personal message. changes after payment need an explicit amendment and potentially a new quote. unavailable characters and unsafe geometry cause an error, never a silent substitution.
