# configurable ring bases

an archetype is a creator-authored starting geometry with named, constrained controls. the symbolic name helps someone find a direction. it does **not** let the platform generate its own ring or replace a creator's authorship. [`archetypes.json`](archetypes.json) is a draft machine-readable index, not validated templates.

| base direction | geometry idea | personalized surfaces | don't assume |
|---|---|---|---|
| letter band | shaped band or plaque with one or more integrated glyphs | raised or recessed initials on approved front/interior surfaces | any font works, text remains legible at all sizes, or thin connections survive |
| signet | defined face above a fitted shank | face initial, monogram, compact relief or inside inscription | any uploaded image can be embossed safely |
| affinity / connected | intertwined or meeting band sections that suggest connection | two initials on distinct lobes, inside inscription | this is a generic theme, not a reproduction of a named brand design |
| promise | a creator's chosen band or heart-centered base intended for a promise | short date, initials or message | "promise" is an occasion and story, not one universal ring shape |
| double heart | two joined or adjacent metal hearts with supported necks | one initial per heart or interior band | the narrow bridge remains castable at every size |
| claddagh | traditional hands embracing a crowned heart | maker-approved interior inscription or a subtle bounded initial | removing the hands/crown still makes an authentic claddagh; a modern interpretation must be labeled honestly |
| knot / linked loop | one or more balanced, connected metal loops | initials on an approved plaque or inside band | floating/disconnected loops can be cast and assembled automatically |

all candidates are **concepts** until a creator-developed paracraft base, relief glyph set, size family, separate server validation and partner-approved metal route exist. don't claim novelty or copy another jeweler's finished expression. [the national museum of ireland](https://www.museum.ie/en-IE/Collections-Research/Folklife-Collections/Folklife-Collections-List-%281%29/Other/Curators-Choice/Claddagh-Rings) describes the traditional claddagh hands, heart and crown and their associations with friendship, love and loyalty.
