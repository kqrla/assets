# bracelets

candidate forms from the prototype: bangles, open cuffs, chain-link bracelets, wire-wrapped and bypass pieces. the legacy "tennis" preset suggests stones, so it is **not** a current sculptura offer. decide whether a metal-only repeating-link treatment merits a separately named base instead of reusing a gemstone category.

configurable axes: wrist fit, rigid/open vs articulated body, link/panel count, connected charm or plate, finish and clasp. a clasp choice is only valid if an approved partner can source or produce the matching metal fitting, attach it safely, and test fit and retention. lobster, box, toggle and hook-eye are candidate families; magnetic and other specialized clasps remain research hold without safety and supply evidence. personalized plates follow the [studio validation gate](../configure/personalization.md).
