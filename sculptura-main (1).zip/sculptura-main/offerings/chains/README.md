# chains

prototype vocabulary includes cable, curb, figaro, rolo, box, snake, wheat, herringbone, singapore and ball patterns. this is a vocabulary, **not** proof that paracraft compiles each link or that a casting partner supplies finished chain.

chain offers require measured length, link dimensions, solid alloy, finish, matching end caps/jump rings and clasp, and a verified supplier plus assembly route. distinguish a reproducibly compiled bespoke link from sourced finished chain hardware. no unsupported chain pattern may be inferred from a pendant release. the current [design-release schema](../../contracts/design-release.schema.json) lacks a `chain` type, so a chain-only listing is gated on a versioned contract update and validated production evidence.
