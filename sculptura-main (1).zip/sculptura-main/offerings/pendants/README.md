# pendants

candidate metal shapes include discs, shields, tags, letters, hearts and creator-defined bounded silhouettes from the prototype. an engraving or relief belongs to a versioned production geometry, not merely an image overlay in the listing.

record pendant size and mass, surface available for text or relief, bail/loop type, hole and wall clearance, and connection to an approved chain. a hinged bail is a moving assembly, not an interchangeable fixed loop. a pendant sold without a chain is different from a [necklace assembly](../necklaces/README.md); both need an explicit bill of materials. do not include stones or unfinished promises to set a customer-owned stone.
