# earrings

the existing `jewelryDefaults.js` identifies studs, hoops, drops, climbers, cuffs, wraps, threaders and crawlers. a shape and a backing are separate choices: the same decorative front cannot automatically accept every post, wire, hinged closure or clip. the audited source already contains a category-to-mechanism map, but it has no manufacturer-verified fitting, tolerances or assembly evidence.

[backings](backings.md) explains the hardware families. [`backings.json`](backings.json) holds a **candidate** compatibility matrix for future controls, not an enabled checkout list. each item needs evidence for post type and gauge, attachment, closure tolerance, total mass and balance, metal at skin contact, left/right orientation, quantity, partner supply and assembly, and safe finishing. no blanket "hypoallergenic" claim.

studs and climbers may use posts and separate catches; hoops can have integrated latches; drops can use wires or levers; non-pierced cuffs need neither a pierced post nor a back. non-pierced clip-on versions require their own fitting and geometry, not merely switching a dropdown on a post design. do not treat anatomically distinct piercings as interchangeable.
