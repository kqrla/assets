# earring findings and closures

an earring "back" can be a separate catch, an integrated closure, a hook, or no separate finding. describe the complete assembly, not just the visible front.

| family | candidate mechanisms | compatibility question |
|---|---|---|
| post with catch | friction/butterfly, broad disc, threaded screw, locking catch | is the post geometry made for that exact catch and alloy? screw catches require threaded posts. |
| integrated hoop | hinged click, latch, continuous hoop | does the closure physically match the hoop wire, hinge and deformation limits? |
| hanging | shepherd/french wire, leverback | can the front attach at a validated loop; is balance/retention acceptable? |
| non-pierced | engineered clip-on, ear cuff | is there a purpose-built clip/cuff and contact surface, rather than an unsupported post swap? |
| threader | integrated chain/wire | no detachable back; check chain, termination and motion along the piercing. |

omega, push-fit and locking systems may have maker-specific mating parts. keep them on hold until a named partner supplies a matched set and instructions. material at the piercing may differ from the cast body alloy; store both explicitly. earring placement, post diameter, nickel release, solder/weld suitability and regional requirements need separate evidence. no body-contact or medical claim follows from this list.

[source](../research/sources.md): the legacy mechanism map and a jeweler's comparison of butterfly, screw, french wire, omega, lever and clip fittings. the matrix is a hypothesis to validate, not a supplier specification.
