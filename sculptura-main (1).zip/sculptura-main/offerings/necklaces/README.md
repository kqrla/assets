# necklaces

a necklace is generally a composed offer: a released [pendant](../pendants/README.md) plus an approved [chain](../chains/README.md), length, clasp, and assembly service. it is not a license for the offering system to edit either component's geometry. if sold as a complete assembly, snapshot the exact component releases or supplier specifications, connection compatibility, alloy/finish and quoted assembly price in the order.

a chain-only necklace remains blocked until the [release type contract](../../contracts/design-release.schema.json), supplier route, and fitting validation support it. guest buyers may select only previously approved configurations.
