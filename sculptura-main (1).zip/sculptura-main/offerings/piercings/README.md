# piercings: research hold

`jewelryDefaults.js` includes a piercing type and detailed ear placements. this does **not** constitute safe body jewelry. gauge, threading, end design, wearable length, surface finish, material at the wound, nickel release, sterilization/packaging claims, intended anatomy, and local regulatory requirements need specialist evidence. do not publish a piercing option or infer medical suitability from an ordinary earring backing. this family is tracked to avoid losing source work, not approved for sale.
