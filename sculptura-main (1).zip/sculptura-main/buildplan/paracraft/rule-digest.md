# paracraft rule digest

consolidated manufacturing rules for the paracraft compiler, extracted from scraped sources on 2026-09-23. every value below is machine-extracted from a published source and kept in the source's own words and units; nothing here is invented, and nothing here is active rule data yet.

status legend: every value is **drafted**. a value becomes an active rule only after cross-checking against a second source or a direct partner answer (see [acquire.md](acquire.md)), and after reproducing in the [benchmark harness](benchmarks.md).

the research converges from two passes, in order:

1. **printability:** can the pattern (castable resin or wax) even be printed and handled? this is the first gate.
2. **castability:** will the printed pattern survive burnout and cast cleanly into metal? this is the second gate.

## conflicts worth noting up front

- **wall minimums cluster around 0.7 to 0.8 mm, but not identically:** formlabs recommends 0.7 mm walls for hollow shells in castable wax resin; cooksongold and sculpteo silver both set 0.8 mm minimum external walls; morris & watson publishes no numeric wall minimum at all. hi3dp (generic sla, not casting) uses 0.8 mm minimum and 1.5 mm for functional walls.
- **service envelopes differ wildly:** cooksongold processes designs up to 30 x 50 x 70 mm; sculpteo silver accepts up to 125 x 125 x 100 mm. envelope is per-partner data, never a global constant.
- **shrinkage numbers disagree in kind:** sculpteo silver says up to 2% raw and up to 3% polished (print/cast/finish combined); hi3dp says ~1-2% linear post-cure shrinkage for sla resins; cooksongold applies an unspecified scaling increase themselves. sculptura's models must not double-apply compensation a partner already applies.
- **text rules disagree:** cooksongold wants raised text at least 0.3 mm thick and no more than 0.6 mm high with 0.3 mm letter spacing; sculpteo silver wants readable text 0.5 mm wide and 1.5 mm tall; hi3dp's generic sla guidance says 0.2 mm stroke width at 1 mm height. text rules must be per-partner.
- **holes:** morris & watson requires holes wider than 0.20 mm with depth no more than the opening; cooksongold says avoid holes under 0.5 mm and fill them in cad. both agree on the deeper-than-wide prohibition (as do formlabs and sculpteo for all negative features).


## pass one: printability (pattern side)


### hi3dp sla design guidelines (generic sla, not casting-specific)

| rule | value | condition |
|---|---|---|
| sla layer resolution | 25–50 µm | modern sla machines. |
| xy accuracy | ~100 µm | modern sla machines. |
| practical minimum feature size | 0.5–1 mm | walls, text, and small bosses; for consistent printing and post-processing. |
| minimum feature spacing | at least 1 mm | between small features; avoid fusing during polymerization or post-cure. |
| minimum wall thickness | ≥ 0.8 mm | non-load-bearing geometries. |
| minimum functional wall thickness | ≥ 1.5 mm | parts subject to handling or light loads. |
| wall-thickness transitions | avoid abrupt changes; use fillets | between thick and thin sections; reduce internal stresses. |
| sliding-fit clearance | 0.2–0.3 mm | per mating surface for sliding parts. |
| snap-fit interference | 0.1 mm | stiff resins. |
| snap-fit interference | 0.2 mm | flexible resins. |
| post-cure shrinkage | ~1–2% linear | during post-cure; calibrate with test prints when tight tolerances are critical. |
| shrinkage compensation | scale model by +1–2% or calibrate per resin | when shrinkage causes dimensional inaccuracy. |
| cosmetic-surface orientation | face upward and away from support attachment locations | minimize supports on critical surfaces. |
| steeper feature angle | 45–60° | reduces cross-section per layer and speeds builds; may require more supports. |
| flatter feature angle | 10–30° | improves surface finish with fewer but larger supports. |
| unsupported overhang threshold | >45° | add supports or re-orient to avoid sagging or delamination. |
| support-tip size and shape | small, conical tips; ~0.3 mm diameter | use for fine features. |
| support density | denser | under heavy overhangs; prevent sagging. |
| support placement | recessed or non-visible areas | avoid attaching supports to thin fins and fine text. |
| support-post clearance | ≥ 1 mm | between support posts and thin walls; allow removal without gouging. |
| drainage-hole count | at least two holes per cavity | one for resin evacuation and one for air entry. |
| drainage-hole placement | high and low points | relative to the print orientation. |
| drainage-hole diameter | ≥ 3 mm | standard resins. |
| drainage-hole diameter | up to 5 mm | high-viscosity or filled resins. |
| hollow-cavity wall thickness | ≥ 1.5 mm; nearly uniform | around the cavity; prevent deformation during curing and maintain structural integrity. |
| batch orientation | 45° | batch multiple parts alternatively at 45° to balance fine detail vs. build height. |
| xy-plane rotation | 5–10° | slight rotation to randomize layer artifacts. |
| thin-fin or spike thickness | ≥ 1 mm, or remove altogether | avoid breakage during build or cleanup. |
| engraved-text height | 1 mm tall | standard resins. |
| engraved-text stroke width | 0.2 mm | standard resins; use a test coupon if finer typography is needed. |
| living-hinge flex-area thickness | 0.4–0.6 mm | tough or flexible resin. |
| living-hinge orientation | hinge axis perpendicular to the build plane | living hinges. |

### gaps

- no recommended layer height or layer-count limit for a particular pattern.
- no drainage-hole depth, edge-distance, or detailed placement constraints.
- no jewelry-specific orientation rules for planar faces, hole axes, or undercuts.
- no absolute dimensional tolerance bands or resin-specific shrinkage and accuracy values.


### sculpteo sterling silver casting page

| rule | value | condition |
|---|---|---|
| account requirement | required | before uploading a file to start 3d printing. |
| maximum 3d file size | 50mb | uploaded 3d file. |
| multiple objects in one file | no | a file containing several objects cannot be printed in silver. |
| uploaded file quality | highest quality possible | recommended to avoid triangulation in the final print. |
| standard layer thickness | 25 µm | sterling silver service. |
| accuracy | unpolished max: 0.8mm; polished max: 0.8mm | unpolished or polished finish, respectively. |
| shrinkage consideration | raw: up to 2% (on average); polished: up to 3% (on average) | shrinkage may occur during printing. |
| minimum object size | 2.4 x 2.4 x 0.8 mm | overall object dimensions. |
| maximum object size | 125 x 125 x 100 mm | overall object dimensions. |
| minimum general wall thickness | 0.8 mm | walls must meet this minimum to remain supported without breaking under their own weight. |
| minimum thickness for unsupported, stemmed, or constrained geometry | 1 mm | unsupported or stemmed elements, or parts with a particular design constraint. a stemmed element is at least twice as long as it is thick. |
| wall thickness advised for greater rigidity | 2mm | use when more rigidity is desired; walls at the general minimum are described as slightly flexible. |
| stress-dependent thickening | thicken the most-stressed and fragile areas | malleable silver can distort when too much weight is applied. |
| minimum general detail size | 0.4 mm | recommended as a lower bound for visibility and avoiding breakage; casting fill is a determining factor. |
| minimum embossed detail height and width | 0.5 mm | embossed details. |
| minimum engraved detail height and width | 0.4 mm | engraved details. |
| minimum readable-text dimensions | width: 0.5 mm; height: 1.5 mm | text that must remain readable. |
| enlargement ratio | 1/1 | no feature or finish condition specified. |
| detail width-to-depth relationship | width ≥ depth | for better visibility; detail width must be at least as large as its depth. |
| polishing smoothing risk | too-thin elements and too-sharp edges will be smoothed | when minimum-detail restrictions are not respected. |
| mirror polish effect on details | finer details may be less visible; the interior is not polished | mirror polish; hand polishing uses subtractive polishing, and the interior cannot be reached by hand. |
| online solidity-check workflow | upload the 3d file, select the material, and click the “verification” tab | the tool highlights parts that may be too thin. |
| solidity-check limitations | floating parts, unstable position, and parts supporting too much weight relative to their thickness are not detected | geometry and the most-stressed parts still require particular attention. |
| enclosed parts | no | the wax stage requires supports for otherwise free-floating objects. |
| interlocking parts | no | silver models. |
| minimum spacing between fixed walls | 0.3 mm | required for excess liquid wax to drain; a smaller gap will result in a fault in the final design. |
| minimum clearance between parts | 0.3 mm | required between parts for excess liquid wax to drain. |
| assembly | no | assembled pieces are currently not possible with the silver printing option. |
| hollowing | no | the object is printed in wax before silver casting and cannot be hollowed in the manner described for other materials. |

**gaps**

- accepted file formats, mesh-density requirements, input watertightness criteria, model units/scale, and orientation constraints are not specified.
- numeric minimums for hole or bore diameters, edge/corner radii, draft, undercuts, feature depth, and surface roughness are not given.
- the source does not define the measurement basis for the reported maximum accuracy or explain how to apply the shrinkage percentages as dimensional compensation.


### sculpteo bronze casting page

| rule | value | condition |
|---|---|---|
| upload access | an account is required to upload files and obtain live quotes. | before starting 3d printing or laser cutting. |
| manufacturing process | lost-wax casting | sculpteo’s bronze material. |

## gaps

- **wall thickness:** no minimum wall thickness is provided.
- **feature sizing:** no minimum feature sizes are given for holes, engraving, embossing, or other details.
- **tolerances:** no dimensional or casting tolerances are specified.
- **sizing:** no overall size, bounding-box, volume, scaling, or unit requirements are provided.
- **geometry:** no rules are provided for enclosed, hollow, or interlocking geometry.
- **upload validation:** no accepted file formats, mesh requirements, or automatic rejection criteria are stated.


### raise3d wall thickness reference

| rule | value | condition |
| --- | --- | --- |
| process-specific minimum and maximum wall thickness | not provided in the supplied text | fff, sla, MJF/SLS, and slm appear only in the table of contents. |

**gaps**
- no minimum or maximum wall thickness for fff or any other listed process.
- no material-specific wall-thickness guidance, including for flexible materials or photosensitive resins.
- no jewelry-specific or geometry-dependent wall-thickness rules.

## pass two: castability (metal side)


### formlabs casting whitepaper

| rule | value | condition |
|---|---|---|
| direct investment casting sequence | immerse the master pattern in refractory investment; let it dry and harden; burn out the pattern to leave a negative cavity; pour metal into the cavity. | direct investment casting, also called lost wax casting. |
| third-party casting equipment | certus prestige optima investment; vacuum investment machine; casting system such as neutec j2r. | equipment listed in “essentials” for the described jewelry-casting workflow. |
| ventilation for indoor burnout | use active ventilation, such as vent-a-kiln. | for indoor burnout. |
| listed furnace specification | 732 °c or 1400 °f | third-party furnace listed in “essentials.” the source does not identify this value as a burnout operating temperature. |
| true cast resin thickness capability | up to 5 mm thick | for precision casting intricate jewelry through complex engineering components, including thick jewelry such as heavy class rings. |
| castable wax 40 resin cross-section capability | up to 4 mm | in most places in the model. |
| clear cast resin thickness | large-part geometries: thicker than 3 mm. demanding engineering applications: over 3 mm thick. | clear cast resin is also identified as an option for investment casting large parts. |
| sharp-corner avoidance | avoid sharp corners and edges where possible. | sharp edges increase metal turbulence and concentrate expansion stresses in the mold. |
| negative-feature proportions | keep engraved channels and holes wider than they are deep. | this is a rule of thumb, particularly important for small negative features where the surrounding investment is fragile. |
| investment-breakage symptoms | filled-in negative features such as engraves and stone holes; usually accompanied by rough cast surfaces or pitting. | potential signs of investment breakage; surface roughness or pitting results from investment debris. |
| feed-sprue geometry | design feed sprues either straight or tapered down towards the piece. | applies to feed sprues. |
| use of 3d-printed feed sprues | use only where placing wax sprues would be difficult. | example given: connecting one inaccessible area of the resin pattern to another. |
| sprue-material preference | real wax sprues promote better cast-part quality. | they give the pattern early access to oxygen when it melts out. |
| preform supports as sprues | do not use preform supports as sprues. | when planning to 3d print sprues. |
| printed sprue design | incorporate 3d printed sprues into the cad design. | formlabs recommends this when intending to 3d print sprues. |
| sprue attachment-point design | add a cad sprue attachment point, such as a hole in the bottom of a ring band or a small hollow post to fill or surround with wax when attaching to a sprue rod. | helps attach and retain heavy resin patterns on wax sprues, avoiding a pattern floating in the poured flask. |
| thin-shell strategy | hollow the design to a thin-walled shell. | for large, monolithic castable wax resin designs; the shell minimizes expansion forces on the investment during burnout. |
| castable wax resin shelling trigger | parts thicker than 3 mm should be shelled. | castable wax resin. |
| castable wax resin drain-hole requirement | drain holes must be added to allow resin to flush out of the hollow interior. | when a castable wax resin part is shelled. |
| recommended hollow-shell wall | 0.7 mm thick walls | formlabs recommendation for hollow shells printed in castable wax resin; described as the minimum wall thickness. |
| shell-operation inspection | check for areas close to, or less than, double the minimum 0.7 mm wall thickness. | for hollow, thin-shelled castable wax resin patterns; shell cad may not touch these areas, leaving regions too thick for casting. |
| interior lattice | a lattice can be added. | to improve handling strength of large shelled parts printed in castable wax resin. |
| excessively thick-part risk | excessively thick parts are likely to cause expansion cracks. | during burnout. |

### gaps

- no post-cure protocol, wash sequence, or wash/cure times and temperatures.
- no drain-hole diameter, count, or placement rules; no complete shell-cad procedure.
- no sprue-tree counts, diameters, lengths, or minimum wax-attachment dimensions.
- no burnout process temperature, heating rate, or hold times. the listed furnace value is not identified as an operating setpoint.
- no investment thickness, permeability limits, investment recipe, or metal-pouring temperature and pressure requirements.


### morris and watson cad design guidelines

| rule | value | condition |
| --- | --- | --- |
| Edge/point/corner radius | ≥ 0.125 mm | all edges, points and corners, including split shanks and lettering |
| void depth | depth ≤ opening width | lettering, stone holes, fine gaps and spaces |
| maximum recommended hole depth | ≤ 0.30 mm | holes |
| gap between non-touching components | ≥ 0.20 mm | claws, setting posts, walls and similar components |
| gap too small to maintain | fill the gap and drill it out later | if a gap of ≥ 0.20 mm is not possible |
| hole diameter | > 0.20 mm | any hole |
| hole depth relative to opening | depth ≤ diameter or opening width | any hole |
| pilot-hole design | use a small pilot divot; drill the full hole later | if the design requires holes |
| cad model integrity | no naked edges; watertight model | model geometry; both are listed as common casting issues |
| support and metal flow | avoid thin or unsupported components and designs that restrict metal flow | model design; no numeric definition of “thin” is supplied |

- no numeric minimum section/wall thickness, shrinkage allowance, sprue requirements or alloy-specific casting rules are provided.
- hole-depth guidance is not reconciled: the source states both ≤ 0.30 mm maximum depth and depth ≤ opening width/diameter.


### cooksongold casting design tips

| rule | value | condition |
|---|---|---|
| model watertightness | must be watertight, with no naked or non-manifold edges | before upload; these issues often arise from shared edges or points |
| maximum design dimensions | 30mm x 50mm x 70mm | designs must fit within these dimensions; larger files are not processed |
| external wall thickness | minimum 0.8mm | external walls |
| small-element thickness | minimum 0.5mm | smaller elements, such as claws or setting bezels |
| earring posts | omit from the printed model; solder after casting | earring posts are not recommended for printing because of their delicate nature |
| raised text thickness | at least 0.3mm | raised text |
| raised text height | no more than 0.6mm | raised text |
| raised letter spacing | minimum 0.3mm | between raised letters |
| recessed text thickness | at least 0.3mm | recessed text |
| recessed text depth | no more than 0.5mm | recessed text |
| recessed letter spacing | minimum 0.3mm | between recessed letters |
| small holes | avoid holes smaller than 0.5mm; fill them during cad | small holes that can cause casting issues |
| pilot-hole geometry | use conical or spherical shapes; pilot divot width must be larger than its depth | if pilot holes are necessary for settings |
| detail geometry recommendation | apply a negative draft angle (taper); round or fillet sharp edges | when incorporating text or intricate details |
| hollow construction | not processed; cast two halves separately, then solder or weld together | if the design would otherwise be hollow |
| interlocking or multiple-piece construction | cast individual components and assemble afterward | interlocking or multiple-piece designs |
| sprue placement | leave placement to cooksongold; communicate specific preferences directly to the team | customer-added sprues can increase stl volume and cost |
| shrinkage compensation | cooksongold applies a scaling increase | to compensate for shrinkage and match intended final dimensions |
| material removed by polishing | approximately 0.1mm | during polishing; the amount depends on the processes used |
| high-shine finishing allowance | add extra material to help preserve intended dimensions | areas intended for a high-shine finish |

### gaps

- no numerical shrinkage factor or general dimensional tolerance.
- no draft-angle magnitude, fillet radius, or minimum mesh-repair overlap/local thickening.
- no general minimum feature size beyond the specified walls, text, and holes.
- no stl resolution requirement or sprue dimensions and placement coordinates.


### formlabs castable wax resin support

| rule | value | condition |
|---|---|---|
| material formulation | a 20% wax-filled material; an acrylate photopolymer formulated with liquid wax. | castable wax resin. |
| equipment compatibility | use a compatible formlabs sla printer and compatible resin tank; check the resin tank compatibility table before use. | tank compatibility is required to avoid equipment damage. |
| print prerequisites | compatible printer with up-to-date firmware, most recent version of preform software, and build platform. | castable wax printing. |
| preform preparation | install or update preform, open the model, and set up the print job. | castable wax print preparation. |
| listed equipment | form wash or finish kit; form cure. | required-resource list; the casting workflow separately specifies washing followed by casting without post-curing. |
| post-processing before casting | wash, then cast; no post-cure is required. | direct investment casting with castable wax. |
| cad resource | jewelry-specific cad software, such as jewelcad or rhinogold. | required third-party resources. |
| investment for standard burnout schedule | certus prestige optima. | recommended investment. |
| investment for short burnout schedule | nobilium microfire. | recommended investment. |
| burnout oven capability | oven capable of 750 °c. | required resource; this is oven capability, not a stated burnout-stage setpoint. |
| casting equipment | vacuum chamber and casting system, such as indutherm mc-series or the neutec j2r; compressed air. | required third-party resources. |
| abrasive | sandpaper, 400 grit or above. | listed required resource; the supplied text does not assign a specific surface-preparation operation. |
| recommended pattern types | direct investment casting of jewelry models, including delicate features such as filigree, pavé geometries, thin walls, and fine surface details. | castable wax resin. |
| prototype use | prints are strong enough for prototyping and fitting. | before production. |
| not recommended | final or functional parts; large, bulky patterns. | castable wax resin. |
| castable-resin selection | smaller parts or wire filigree: castable wax resin. medium to heavy jewelry or small engineering components: true cast resin. larger investment casting: clear cast resin. | when selecting among the listed formlabs castable resins. |
| burnout ventilation | design airflow vents in thick or large geometries to allow sufficient ventilation during burnout. | casting pattern design. |

### gaps

- the supplied text gives no layer heights, print resolution, exposure settings, orientation rules, support rules, or printer-specific material/tank pairings.
- no numeric geometry limits are given for walls, holes, channels, prongs, or other delicate features, nor numeric size thresholds for the “smaller,” “medium to heavy,” or “larger” categories.
- complete standard and short burnout schedules are absent: no stage temperatures, heating rates, hold times, cooling requirements, or maximum ramp rates. the only thermal number is the **750 °c** oven capability.
- investment compatibility is limited to two recommendations; the source excerpt supplies no powder/liquid ratios, mixing sequence, working time, vacuum/degas parameters, or investment-to-pattern ratio.


### formlabs true cast resin support

| rule | value | condition |
| --- | --- | --- |
| precision-casting thickness limit | up to 5 mm thick | for intricate jewelry and complex engineering components. |
| wire-filigree restriction | not recommended; use castable wax resin | for wire filigree. |
| oversize-part restriction | not recommended; use clear cast resin | for parts larger than 5 mm thick. |
| printing layer height | 25 microns and 50 microns | for true cast resin printing with a compatible printer. |
| ash content | 0.03% | stated for true cast resin in connection with clean burnout. |
| workflow step 1, pattern design | design the part in cad software | before the casting workflow proceeds to resin conditioning. |
| workflow step 2, pre-heat and mix | heat, then mix the resin before printing | ensure the wax component is completely liquid and evenly dispersed. |
| resin-heating equipment | resin heater | required third-party resource for pre-heating. |
| workflow step 3, pattern printing | 3d print with true cast resin, following formlabs instructions | after pre-heating and mixing. |
| workflow step 4, initial wash | thoroughly clean the printed patterns with ipa | remove residual uncured resin. |
| workflow step 4, second wash | rinse for a second time in clean ipa | ensure the patterns are completely clean. |
| uncured-resin defect risk | uncured resin on parts | may result in casting defects. |
| workflow step 5, drying | dry with compressed air | only the step title is present in the provided excerpt. |
| formlabs printing resources | compatible formlabs sla printer, build platform, compatible resin tank, true cast resin, and preform software | use up-to-date printer firmware and the most recent preform version. |
| third-party printing resource | compatible resin printer | listed among required third-party resources. |
| washing and post-curing resources | form wash (2nd generation) or another washing system; form cure (2nd generation) or another post-curing system | required for washing and post-curing. |
| burnout and casting equipment | burnout oven; vacuum chamber and casting system, such as the neutec j2r | listed third-party required resources. |
| ancillary equipment | end nippers, flasks, investment, vacuum, wax, waxing tools, etc. | listed third-party required resources; investment details are not specified. |
| cleaning alcohol | ipa or ethyl alcohol, concentration of 91% or higher | required cleaning resource. |
| abrasive | sandpaper (1000 grit) | listed ancillary resource; no sanding procedure is provided. |

### gaps

- investment material, composition, mixing ratio, vacuum-investment procedure, and investment-setting requirements.
- preheat temperature or time, printer exposure and orientation, wash and post-curing schedules, and burnout and casting schedules.
- minimum feature size, minimum wall thickness, undercuts, draft angles, dimensional tolerances, or how the 5 mm limit maps to cad geometry.
- compressed-air drying pressure, duration, or method beyond the workflow step title.

## openscad compiler notes


### openscad manual: stl import and export

| rule | value | condition |
| --- | --- | --- |
| stl geometry importer | `import()` | importing external geometry. |
| supported 3d geometry formats | stl (both ascii and binary), off, obj, amf (deprecated), 3mf | importing geometry with `import()`. |
| gui command insertion | `File >> Open` may insert `import()`; enter a wildcard such as `*.stl` when the file-type filter shows only openscad files | requires version `2015.03-2`. |
| legacy stl importer | `import_stl()` is deprecated; use `import()` | removal is deferred to a future release; no removal version is given. |
| relative `file` path | resolved relative to the importing script | the given path is not absolute. |
| relative path through inclusion | resolved relative to the script doing the `include<>` | a script loaded with `include<>` uses `import()`. |
| object placement | `center` is boolean; `true` places the object’s center at the origin | `center=true` on the `import()` module. |
| preview convexity | optional integer `convexity`: maximum number of front sides, or back sides, a ray intersecting the object might penetrate | needed for correct display in opencsg preview mode; has no effect on polyhedron rendering. |
| suggested convexity | `10` | should work fine for most cases; not stated as a default. |
| polygon segment count | `$fn`: double specifying the number of polygon segments | converting circles, arcs, and curves to polygons; requires version `Development snapshot`. |
| minimum angle step | `$fa`: double | converting circles and arcs to polygons; requires version `Development snapshot`. |
| minimum segment length | `$fs`: double | converting circles and arcs to polygons; requires version `Development snapshot`. |
| stl cleanliness | the mesh has to be manifold and should contain neither holes nor self-intersections | an imported stl must be rendered later. |
| failure modes for unclean stl | possible outcomes include manifold warnings, disappearance from output, or cgal assertion violations | computational geometry is performed, such as rendering the stl combined with another object. |
| repair-tool capabilities | semi-automatic repair options repairs holes but not self-intersections; netfabb basic does neither; meshlab can fix all listed issues | repairing an imported stl. |
| meshlab non-manifold check | the screen should show `0 non manifold edges` and `0 non manifold vertices` | after the documented selection, closure, and vertex-deletion cleanup step. |
| meshlab stl export | `File → Export Mesh`; save as stl | after repairing the mesh in meshlab. |
| experimental data-import flag | enable `import-function`; only json files are supported | using the `import()` function for data rather than geometry; requires version `Development snapshot`. |

### gaps

- the source provides no stl export command or syntax, export cli flags, or export-side ASCII/Binary selection rules.
- it gives no byte-reproducibility guarantees, including guarantees for triangle order, vertex order, or coordinate formatting.
- it gives no numeric mesh-validation tolerances, hole-size limits, vertex-merge distances, repair-pass counts, or default `convexity`.
- it provides no pinned command-line workflow; features labeled `Development snapshot` have no fixed release number here.
- it does not specify cad units, physical-size mapping, coordinate orientation, or whether the polygon-conversion parameters affect imported stl meshes.


### openscad manual: customizer

| fact | detail |
|---|---|
| version requirement | the customizer feature requires openscad version 2019.05. |
| purpose | customizer exposes model parameters for gui editing, avoiding code edits. saved parameter sets can represent model variants. |
| main-file scope | only variables assigned in the main file are displayed. variables assigned in files loaded through `include` or `use` are not displayed. |
| supported value types | supported values are strings, numbers, booleans, or lists containing at most four numeric literals. |
| unsupported expressions | expressions are unsupported even when trivial, including `str("String"," ","concat")` and `12 + 0.5`. |
| assignment position | a supported assignment must appear before the first `{` syntax element. |
| hidden section | a line containing only `/* [Hidden] */` prevents subsequent assignments in that section from being displayed. this is described as the best-practice cutoff. |
| non-stopping declaration | a module or function declaration containing no `{` does not stop customizer; subsequent supported assignments remain displayed. |
| legacy cutoff | an empty module such as `module __Customizer_Limit__ () {}` places a `{` in the file and hides following assignments from customizer. |
| description syntax | a description uses a `//` comment on the line above an assignment. the description comment must align with the source file’s left column without spaces. |
| drop-down annotation | a trailing `// [...]` annotation lists number or string choices, e.g. `Numbers=2; // [0, 1, 2, 3]` or `Strings="foo"; // [foo, bar, baz]`. |
| labeled drop-down annotation | choices may use `value:label`, e.g. `Labeled_values=10; // [10:S, 20:M, 30:L]` or `Labeled_value="S"; // [S:Small, M:Medium, L:Large]`. |
| slider annotation | sliders accept numbers only. `// [50]` specifies a maximum; `// [10:100]` specifies minimum and maximum. |
| step-slider annotation | `// [0:5:100]` specifies minimum, step, and maximum; the example uses minimum `-10`, step `0.1`, and maximum `10`. |
| slider compatibility | maximum-only slider syntax, `// [50]`, is mainly provided for thingiverse compatibility. |
| checkbox annotation | a boolean assignment such as `Variable = true;` uses a checkbox. checkboxes are not supported by thingiverse. |
| spinbox annotation | `Spinbox = 5;` uses step size 1; `Spinbox = 5.5; // .5` specifies step size 0.5. |
| textbox compatibility | the supplied note states that the textbox example works in release 2021.01 and may not work in future versions. |

gaps:
- ordered and named module/function parameters are not covered in the supplied source.
- general customizer section syntax is absent beyond the `[Hidden]` section.
- the textbox section is truncated; its example and complete compatibility statement are missing.


### openscad downloads and versions

| rule | value | condition |
| --- | --- | --- |
| stable release version listed | `2021.01` | macos, windows, other linux, and source-code downloads |
| stable macos artifact | `OpenSCAD-2021.01.dmg`; 64 bit intel; `27 MB` | macos |
| stable windows artifacts | `OpenSCAD-2021.01-x86-32-Installer.exe`; `OpenSCAD-2021.01-x86-32.zip`; `OpenSCAD-2021.01-x86-64-Installer.exe`; `OpenSCAD-2021.01-x86-64.zip`; `21 MB` per package | windows; x86 (32-bit) and x86 (64-bit) |
| stable other linux artifacts | `OpenSCAD-2021.01-x86_64.AppImage`; x86 (64-bit); `39 MB`; `OpenSCAD-2021.01-aarch64.AppImage`; arm (64-bit); `43 MB` | other linux |
| stable source artifact | `openscad-2021.01.src.tar.gz`; `16 MB` | source code |
| checksum file types linked | `sha256`; `sha512` | stable-artifact and release candidate download entries |
| signature file type linked | `asc` | stable windows, other linux, and source-code downloads; release candidate entries |
| listed gnupg key id | `0x8AF822A975097442` | release candidates; binaries signed with gnupg |
| listed gnupg fingerprint | `B3C9 4B42 50DC 097E 9FFF 8177 8AF8 22A9 7509 7442` | release candidates; binaries signed with gnupg |
| release candidate content | all features that will be included in the next release | intended for testing before the final release |
| docker image release and base | `2021.01`; based on debian buster | `openscad/openscad` image; `linux/amd64` |
| docker image release and base | `2019.05`; based on debian buster | `openscad/openscad` image; `linux/amd64` |
| docker image release and base | `2015.03`; based on debian stretch | `openscad/openscad` image; `linux/amd64` |
| docker development channel and base | development snapshot; based on debian bookworm | `openscad/openscad` image; `linux/amd64` |

**gaps**

- no complete release history, release dates, or changelog.
- no exact version/date is shown for nightly builds, development snapshot images, or release candidate downloads.
- no literal `sha256` or `sha512` values are included; only checksum-file links.
- package-manager entries do not provide the versions they currently resolve to.
- no output-compatibility guarantees or explicit version-scheme rules are stated.


## next extraction targets

- the openscad 2d/3d primitives manual page failed to scrape (the retrieval returned a missing-page notice); the language reference for primitives and resolution variables still needs a clean pull.
- gildform's model requirements page rate-limited twice; it moves to the ask list.
- per the gaps lists above: every partner's shrinkage factor, dimensional tolerance, sprue dimensions, and burnout setpoints remain unpublished and move to [acquire.md](acquire.md).
