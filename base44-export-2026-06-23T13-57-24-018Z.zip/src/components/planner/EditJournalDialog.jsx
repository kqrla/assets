const db = globalThis.__B44_DB__ || { auth:{ isAuthenticated: async()=>false, me: async()=>null }, entities:new Proxy({}, { get:()=>({ filter:async()=>[], get:async()=>null, create:async()=>({}), update:async()=>({}), delete:async()=>({}) }) }), integrations:{ Core:{ UploadFile:async()=>({ file_url:'' }) } } };

import React, { useState, useEffect } from "react";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";

const COLORS = [
  { value: "red", hex: "#cc4b48" },
  { value: "blue", hex: "#2e95aa" },
  { value: "yellow", hex: "#fed754" },
  { value: "green", hex: "#abc3b5" },
  { value: "navy", hex: "#2c3e6b" },
  { value: "burgundy", hex: "#7a2841" },
  { value: "teal", hex: "#1a8a7a" },
  { value: "coral", hex: "#e8755a" },
];

const STYLES = ["plain", "ruled", "squared", "dotted"];

export default function EditJournalDialog({ open, onOpenChange, journal, mode, onSaved }) {
  const [value, setValue] = useState("");
  const [saving, setSaving] = useState(false);

  useEffect(() => {
    if (!journal) return;
    if (mode === "type") setValue(journal.page_style || "ruled");
    if (mode === "rename") setValue(journal.title || "");
    if (mode === "label") setValue(journal.label || journal.title || "");
    if (mode === "color") setValue(journal.color || "red");
  }, [journal, mode, open]);

  const titleMap = {
    type: "edit type",
    rename: "rename",
    color: "edit cover color",
    label: "edit cover label",
  };

  const handleSave = async () => {
    setSaving(true);
    const update = {};
    if (mode === "type") update.page_style = value;
    if (mode === "rename") update.title = value.trim();
    if (mode === "color") update.color = value;
    if (mode === "label") update.label = value.trim();
    await db.entities.Journal.update(journal.id, update);
    setSaving(false);
    onSaved({ ...journal, ...update });
    onOpenChange(false);
  };

  const renderContent = () => {
    if (mode === "type") {
      return (
        <div className="flex gap-2">
          {STYLES.map((s) => (
            <button
              key={s}
              onClick={() => setValue(s)}
              className="px-3 py-1.5 rounded-md text-xs font-body lowercase tracking-wider transition-all"
              style={{
                backgroundColor: value === s ? "hsl(38, 60%, 65%)" : "hsl(30, 8%, 18%)",
                color: value === s ? "hsl(30, 15%, 8%)" : "hsl(30, 10%, 55%)",
              }}
            >
              {s}
            </button>
          ))}
        </div>
      );
    }
    if (mode === "color") {
      return (
        <div className="flex gap-2 flex-wrap">
          {COLORS.map((c) => (
            <button
              key={c.value}
              onClick={() => setValue(c.value)}
              className="w-9 h-9 rounded-lg transition-all duration-200"
              style={{
                backgroundColor: c.hex,
                outline: value === c.value ? "2px solid hsl(38, 60%, 65%)" : "none",
                outlineOffset: 2,
                transform: value === c.value ? "scale(1.1)" : "scale(1)",
              }}
            />
          ))}
        </div>
      );
    }
    return (
      <Input
        value={value}
        onChange={(e) => setValue(e.target.value)}
        className="bg-secondary border-border lowercase"
      />
    );
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="bg-card border-border max-w-md">
        <DialogHeader>
          <DialogTitle className="font-heading text-xl lowercase">{titleMap[mode] || "edit"}</DialogTitle>
        </DialogHeader>
        <div className="space-y-4 pt-2">
          {renderContent()}
          <Button onClick={handleSave} disabled={saving || (mode !== "color" && mode !== "type" && !value.trim())} className="w-full lowercase">
            {saving ? "saving…" : "save"}
          </Button>
        </div>
      </DialogContent>
    </Dialog>
  );
}