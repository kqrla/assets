const db = globalThis.__B44_DB__ || { auth:{ isAuthenticated: async()=>false, me: async()=>null }, entities:new Proxy({}, { get:()=>({ filter:async()=>[], get:async()=>null, create:async()=>({}), update:async()=>({}), delete:async()=>({}) }) }), integrations:{ Core:{ UploadFile:async()=>({ file_url:'' }) } } };

import React, { useState } from "react";
import { useNavigate } from "react-router-dom";
import {
  ContextMenu,
  ContextMenuTrigger,
  ContextMenuContent,
  ContextMenuItem,
  ContextMenuSeparator,
  ContextMenuSub,
  ContextMenuSubTrigger,
  ContextMenuSubContent,
} from "@/components/ui/context-menu";
import EditJournalDialog from "@/components/planner/EditJournalDialog";

const COLOR_MAP = {
  red: { bg: "#cc4b48", dark: "#9c2e2b" },
  blue: { bg: "#2e95aa", dark: "#1e606e" },
  yellow: { bg: "#fed754", dark: "#ebb501" },
  green: { bg: "#abc3b5", dark: "#7ea38e" },
  navy: { bg: "#2c3e6b", dark: "#1a2540" },
  burgundy: { bg: "#7a2841", dark: "#55192d" },
  teal: { bg: "#1a8a7a", dark: "#0f5c52" },
  coral: { bg: "#e8755a", dark: "#c45a3e" },
};

const PAGE_PATTERNS = {
  plain: "none",
  ruled: "linear-gradient(#e4ddd0 0px, #e4ddd0 1px, transparent 1px)",
  squared: "linear-gradient(#e4ddd0 1px, transparent 1px), linear-gradient(90deg, #e4ddd0 1px, transparent 1px)",
  dotted: "radial-gradient(circle, #bbb 0.8px, transparent 0.8px)",
};

const PAGE_SIZES = {
  plain: "auto",
  ruled: "100% 9px",
  squared: "10px 10px",
  dotted: "11px 11px",
};

export default function NotebookCard({ journal: initialJournal, onJournalUpdated, onJournalDeleted }) {
  const [journal, setJournal] = useState(initialJournal);
  const [isHovered, setIsHovered] = useState(false);
  const [editMode, setEditMode] = useState(null);
  const [editOpen, setEditOpen] = useState(false);
  const navigate = useNavigate();

  const colors = COLOR_MAP[journal.color] || COLOR_MAP.red;
  const elasticBand = `linear-gradient(to right, ${colors.dark} 0%, ${colors.bg} 12%, ${colors.dark} 25%, ${colors.bg} 37%, ${colors.dark} 50%, ${colors.bg} 62%, ${colors.dark} 75%, ${colors.bg} 87%, ${colors.dark} 100%)`;
  const labelText = (journal.label || journal.title).toUpperCase();

  const openEdit = (mode) => {
    setEditMode(mode);
    setEditOpen(true);
  };

  const handleSaved = (updated) => {
    setJournal(updated);
    if (onJournalUpdated) onJournalUpdated(updated);
  };

  const handleDuplicate = async () => {
    const dup = await db.entities.Journal.create({
      title: journal.title + " (copy)",
      label: journal.label,
      color: journal.color,
      page_style: journal.page_style,
      pages: journal.pages || [{ content: "", page_number: 1 }],
    });
    if (onJournalUpdated) onJournalUpdated(dup);
  };

  const handleDelete = async () => {
    await db.entities.Journal.delete(journal.id);
    if (onJournalDeleted) onJournalDeleted(journal.id);
  };

  return (
    <>
      <ContextMenu>
        <ContextMenuTrigger>
          <div
            className="flex flex-col items-center gap-3 cursor-pointer select-none"
            onMouseEnter={() => setIsHovered(true)}
            onMouseLeave={() => setIsHovered(false)}
            onClick={() => navigate(`/journal/${journal.id}`)}
          >
            <div
              className="relative transition-transform duration-500 ease-out"
              style={{
                height: 250,
                width: 175,
                perspective: 900,
                transform: isHovered ? "rotate(-8deg)" : "rotate(0deg)",
              }}
            >
              <div
                className="absolute inset-0 rounded-r-2xl rounded-l"
                style={{
                  backgroundColor: "#fbfae8",
                  backgroundImage: PAGE_PATTERNS[journal.page_style] || "none",
                  backgroundSize: PAGE_SIZES[journal.page_style] || "auto",
                  zIndex: 0,
                }}
              />

              <div
                className="absolute inset-0 rounded-r-2xl rounded-l"
                style={{
                  backgroundColor: colors.bg,
                  zIndex: 10,
                  transformOrigin: "left center",
                  transform: `rotateY(${isHovered ? -50 : 0}deg)`,
                  transition: "transform 0.5s ease-out, box-shadow 0.5s ease-out",
                  boxShadow: isHovered
                    ? "18px 8px 40px rgba(0,0,0,0.28)"
                    : "2px 2px 10px rgba(0,0,0,0.12)",
                  backfaceVisibility: "hidden",
                }}
              >
                <div
                  className="absolute rounded-sm"
                  style={{
                    width: 8,
                    height: "calc(100% + 2px)",
                    top: -1,
                    right: 22,
                    zIndex: 100,
                    background: elasticBand,
                  }}
                />

                <div
                  className="relative z-10 text-left px-4 py-3"
                  style={{
                    marginTop: 80,
                    background: "#e8e8e0",
                    fontSize: 11,
                    fontFamily: "var(--font-mono)",
                    fontWeight: 700,
                    color: "#333",
                    textTransform: "uppercase",
                    letterSpacing: "0.12em",
                    boxShadow: "0 1px 1px rgba(0,0,0,0.2)",
                    height: 50,
                  }}
                >
                  <span>{labelText.length > 18 ? labelText.slice(0, 18) + "…" : labelText}</span>
                  <div
                    className="absolute bottom-0 left-0 w-full"
                    style={{ height: 12, background: "#cddc39" }}
                  />
                </div>
              </div>
            </div>

            <p className="text-xs font-body text-muted-foreground font-medium lowercase">
              {journal.title}
            </p>
          </div>
        </ContextMenuTrigger>

        <ContextMenuContent className="w-48 bg-card border-border">
          <ContextMenuItem onClick={() => openEdit("type")} className="lowercase cursor-pointer">
            edit type
          </ContextMenuItem>
          <ContextMenuItem onClick={() => openEdit("rename")} className="lowercase cursor-pointer">
            rename
          </ContextMenuItem>
          <ContextMenuSeparator />
          <ContextMenuSub>
            <ContextMenuSubTrigger className="lowercase">
              edit cover style
            </ContextMenuSubTrigger>
            <ContextMenuSubContent className="w-40 bg-card border-border">
              <ContextMenuItem onClick={() => openEdit("color")} className="lowercase cursor-pointer">
                edit cover color
              </ContextMenuItem>
              <ContextMenuItem onClick={() => openEdit("label")} className="lowercase cursor-pointer">
                edit cover label
              </ContextMenuItem>
            </ContextMenuSubContent>
          </ContextMenuSub>
          <ContextMenuSeparator />
          <ContextMenuItem onClick={handleDuplicate} className="lowercase cursor-pointer">
            duplicate
          </ContextMenuItem>
          <ContextMenuItem onClick={handleDelete} className="text-red-400 lowercase cursor-pointer">
            delete
          </ContextMenuItem>
        </ContextMenuContent>
      </ContextMenu>

      <EditJournalDialog
        open={editOpen}
        onOpenChange={setEditOpen}
        journal={journal}
        mode={editMode}
        onSaved={handleSaved}
      />
    </>
  );
}