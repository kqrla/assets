const db = globalThis.__B44_DB__ || { auth:{ isAuthenticated: async()=>false, me: async()=>null }, entities:new Proxy({}, { get:()=>({ filter:async()=>[], get:async()=>null, create:async()=>({}), update:async()=>({}), delete:async()=>({}) }) }), integrations:{ Core:{ UploadFile:async()=>({ file_url:'' }) } } };

import React, { useState, useCallback, useRef, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import { motion, AnimatePresence } from "framer-motion";
import { ChevronLeft, ChevronRight } from "lucide-react";
import {
  ContextMenu,
  ContextMenuTrigger,
  ContextMenuContent,
  ContextMenuItem,
  ContextMenuSeparator,
  ContextMenuSub,
  ContextMenuSubTrigger,
  ContextMenuSubContent,
} from "@/components/ui/context-menu";
import EditJournalDialog from "@/components/planner/EditJournalDialog";

const COLOR_MAP = {
  red: { bg: "#cc4b48", dark: "#9c2e2b" },
  blue: { bg: "#2e95aa", dark: "#1e606e" },
  yellow: { bg: "#fed754", dark: "#ebb501" },
  green: { bg: "#abc3b5", dark: "#7ea38e" },
  navy: { bg: "#2c3e6b", dark: "#1a2540" },
  burgundy: { bg: "#7a2841", dark: "#55192d" },
  teal: { bg: "#1a8a7a", dark: "#0f5c52" },
  coral: { bg: "#e8755a", dark: "#c45a3e" },
};

const PAGE_PATTERNS = {
  plain: "none",
  ruled: "linear-gradient(#e4ddd0 0px, #e4ddd0 1px, transparent 1px)",
  squared: "linear-gradient(#e4ddd0 1px, transparent 1px), linear-gradient(90deg, #e4ddd0 1px, transparent 1px)",
  dotted: "radial-gradient(circle, #bbb 0.8px, transparent 0.8px)",
};

const PAGE_SIZES = {
  plain: "auto",
  ruled: "100% 9px",
  squared: "10px 10px",
  dotted: "11px 11px",
};

const NUM_PAGES = 7;
const START_ANGLE = 45;
const ANGLE_STEP = START_ANGLE / NUM_PAGES;

// CodePen trap-zone page angles: 8 zones × 7 pages + 1 cover
// zone 0 = left edge, zone 7 = right edge; mouseX maps continuously across 8 zones
const TRAP_ANGLES = [
  // zone 0: all pages on right side (slight fan)
  [-45, -38.57, -32.14, -25.71, -19.29, -12.86, -6.43],
  // zone 1: page 0 flips left, rest on right
  [-141.43, -45, -38.57, -32.14, -25.71, -19.29, -12.86],
  // zone 2
  [-147.86, -141.43, -45, -38.57, -32.14, -25.71, -19.29],
  // zone 3
  [-154.29, -147.86, -141.43, -45, -38.57, -32.14, -25.71],
  // zone 4
  [-160.71, -154.29, -147.86, -141.43, -45, -38.57, -32.14],
  // zone 5
  [-167.14, -160.71, -154.29, -147.86, -141.43, -45, -38.57],
  // zone 6
  [-173.57, -167.14, -160.71, -154.29, -147.86, -141.43, -45],
  // zone 7: all pages flipped left
  [-180, -173.57, -167.14, -160.71, -154.29, -147.86, -141.43],
];

// Cover angles (index 0-7): always less than any page at same zone
const COVER_TRAP_ANGLES = [0, -6.43, -12.86, -19.29, -25.71, -32.14, -38.57, -45];

const getPageRotation = (mouseX, pageIdx) => {
  if (mouseX < 0) return 0;
  const zoneFloat = mouseX * 8;
  const t = Math.min(7, Math.floor(zoneFloat));
  const progress = zoneFloat - t;
  if (t >= 7) return TRAP_ANGLES[7][pageIdx];
  return TRAP_ANGLES[t][pageIdx] + (TRAP_ANGLES[t + 1][pageIdx] - TRAP_ANGLES[t][pageIdx]) * progress;
};

const getCoverRotation = (mouseX) => {
  if (mouseX < 0) return 0;
  const zoneFloat = mouseX * 8;
  const t = Math.min(7, Math.floor(zoneFloat));
  const progress = zoneFloat - t;
  if (t >= 7) return COVER_TRAP_ANGLES[7];
  return COVER_TRAP_ANGLES[t] + (COVER_TRAP_ANGLES[t + 1] - COVER_TRAP_ANGLES[t]) * progress;
};

const TRANSITION_SPEED = "transform 0.75s ease-out";

export default function SlideshowView({ journals: initialJournals, onJournalUpdated }) {
  const [journals, setJournals] = useState(initialJournals);
  const [current, setCurrent] = useState(0);
  const [mouseX, setMouseX] = useState(-1);
  const [editMode, setEditMode] = useState(null);
  const [editOpen, setEditOpen] = useState(false);
  const cardRef = useRef(null);
  const navigate = useNavigate();

  useEffect(() => {
    setJournals(initialJournals);
  }, [initialJournals]);

  const handleMouseMove = useCallback((e) => {
    if (!cardRef.current) return;
    const rect = cardRef.current.getBoundingClientRect();
    setMouseX(Math.max(0, Math.min(1, (e.clientX - rect.left) / rect.width)));
  }, []);

  const handleMouseLeave = useCallback(() => {
    setMouseX(-1);
  }, []);

  if (!journals.length) return null;

  const journal = journals[current];
  const colors = COLOR_MAP[journal.color] || COLOR_MAP.red;
  const elasticBand = `linear-gradient(to right, ${colors.dark} 0%, ${colors.bg} 12%, ${colors.dark} 25%, ${colors.bg} 37%, ${colors.dark} 50%, ${colors.bg} 62%, ${colors.dark} 75%, ${colors.bg} 87%, ${colors.dark} 100%)`;
  const labelText = (journal.label || journal.title).toUpperCase();

  const next = () => setCurrent((c) => (c + 1) % journals.length);
  const prev = () => setCurrent((c) => (c - 1 + journals.length) % journals.length);

  const openEdit = (mode) => {
    setEditMode(mode);
    setEditOpen(true);
  };

  const handleSaved = (updated) => {
    const newJournals = journals.map((j) => (j.id === updated.id ? updated : j));
    setJournals(newJournals);
    if (onJournalUpdated) onJournalUpdated(updated);
  };

  const handleDuplicate = async () => {
    const dup = await db.entities.Journal.create({
      title: journal.title + " (copy)",
      label: journal.label,
      color: journal.color,
      page_style: journal.page_style,
      pages: journal.pages || [{ content: "", page_number: 1 }],
    });
    const newJournals = [...journals, dup];
    setJournals(newJournals);
    if (onJournalUpdated) onJournalUpdated(dup);
  };

  const handleDelete = async () => {
    await db.entities.Journal.delete(journal.id);
    const newJournals = journals.filter((j) => j.id !== journal.id);
    if (current >= newJournals.length && newJournals.length > 0) setCurrent(newJournals.length - 1);
    setJournals(newJournals);
    if (onJournalUpdated) onJournalUpdated(null);
  };

  return (
    <>
      <div className="flex flex-col items-center gap-8">
        <div className="flex items-center gap-8">
          <button
            onClick={prev}
            className="w-12 h-12 rounded-full bg-secondary/60 hover:bg-secondary flex items-center justify-center transition-colors flex-shrink-0"
          >
            <ChevronLeft className="w-5 h-5 text-foreground" />
          </button>

          <ContextMenu>
            <ContextMenuTrigger>
              <div
                ref={cardRef}
                className="cursor-pointer"
                onClick={() => navigate(`/journal/${journal.id}`)}
                onMouseMove={handleMouseMove}
                onMouseLeave={handleMouseLeave}
              >
                <AnimatePresence mode="wait">
                  <motion.div
                    key={journal.id}
                    initial={{ opacity: 0, scale: 0.92 }}
                    animate={{ opacity: 1, scale: 1 }}
                    exit={{ opacity: 0, scale: 0.92 }}
                    transition={{ duration: 0.35, ease: "easeOut" }}
                    className="flex flex-col items-center gap-4"
                  >
                    <div
                      className="relative"
                      style={{
                        height: 380,
                        width: 266,
                        perspective: 1100,
                      }}
                    >
                      {/* Back cover */}
                      <div
                        className="absolute inset-0 rounded-r-2xl rounded-l"
                        style={{
                          backgroundColor: colors.dark,
                          zIndex: -1,
                          transformOrigin: "left center",
                          transform: `rotateY(${getPageRotation(mouseX, 0)}deg)`,
                          transition: TRANSITION_SPEED,
                          backfaceVisibility: "hidden",
                        }}
                      />

                      {/* Pages */}
                      {Array.from({ length: NUM_PAGES }).map((_, idx) => (
                        <div
                          key={idx}
                          className="absolute inset-0 rounded-r-2xl rounded-l"
                          style={{
                            backgroundColor: "#fbfae8",
                            backgroundImage: PAGE_PATTERNS[journal.page_style] || "none",
                            backgroundSize: PAGE_SIZES[journal.page_style] || "auto",
                            zIndex: idx,
                            transformOrigin: "left center",
                            transform: `rotateY(${getPageRotation(mouseX, idx)}deg)`,
                            transition: TRANSITION_SPEED,
                            backfaceVisibility: "hidden",
                          }}
                        />
                      ))}

                      {/* Front cover — always stays on top, never flips past -45° */}
                      <div
                        className="absolute inset-0 rounded-r-2xl rounded-l"
                        style={{
                          backgroundColor: colors.bg,
                          zIndex: NUM_PAGES,
                          transformOrigin: "left center",
                          transform: `rotateY(${getCoverRotation(mouseX)}deg)`,
                          transition: `${TRANSITION_SPEED}, box-shadow 0.75s ease-out`,
                          backfaceVisibility: "hidden",
                          boxShadow: mouseX >= 0
                            ? `${16 + mouseX * 8}px ${8 + mouseX * 4}px ${40 + mouseX * 20}px rgba(0,0,0,0.3)`
                            : "4px 4px 15px rgba(0,0,0,0.2)",
                        }}
                      >
                        <div
                          className="absolute rounded-sm"
                          style={{
                            width: 10,
                            height: "calc(100% + 2px)",
                            top: -1,
                            right: 32,
                            zIndex: 100,
                            background: elasticBand,
                          }}
                        />
                        <div
                          className="relative z-10 text-left px-5 py-4"
                          style={{
                            marginTop: 130,
                            background: "#e8e8e0",
                            fontSize: 15,
                            fontFamily: "var(--font-mono)",
                            fontWeight: 700,
                            color: "#333",
                            textTransform: "uppercase",
                            letterSpacing: "0.12em",
                            boxShadow: "0 1px 1px rgba(0,0,0,0.2)",
                          }}
                        >
                          <span>{labelText}</span>
                          <div
                            className="absolute bottom-0 left-0 w-full"
                            style={{ height: 12, background: "#cddc39" }}
                          />
                        </div>
                      </div>
                    </div>
                    <p className="text-sm font-body text-muted-foreground font-medium lowercase">
                      {journal.title}
                    </p>
                  </motion.div>
                </AnimatePresence>
              </div>
            </ContextMenuTrigger>

            <ContextMenuContent className="w-48 bg-card border-border">
              <ContextMenuItem onClick={() => openEdit("type")} className="lowercase cursor-pointer">
                edit type
              </ContextMenuItem>
              <ContextMenuItem onClick={() => openEdit("rename")} className="lowercase cursor-pointer">
                rename
              </ContextMenuItem>
              <ContextMenuSeparator />
              <ContextMenuSub>
                <ContextMenuSubTrigger className="lowercase">
                  edit cover style
                </ContextMenuSubTrigger>
                <ContextMenuSubContent className="w-40 bg-card border-border">
                  <ContextMenuItem onClick={() => openEdit("color")} className="lowercase cursor-pointer">
                    edit cover color
                  </ContextMenuItem>
                  <ContextMenuItem onClick={() => openEdit("label")} className="lowercase cursor-pointer">
                    edit cover label
                  </ContextMenuItem>
                </ContextMenuSubContent>
              </ContextMenuSub>
              <ContextMenuSeparator />
              <ContextMenuItem onClick={handleDuplicate} className="lowercase cursor-pointer">
                duplicate
              </ContextMenuItem>
              <ContextMenuItem onClick={handleDelete} className="text-red-400 lowercase cursor-pointer">
                delete
              </ContextMenuItem>
            </ContextMenuContent>
          </ContextMenu>

          <button
            onClick={next}
            className="w-12 h-12 rounded-full bg-secondary/60 hover:bg-secondary flex items-center justify-center transition-colors flex-shrink-0"
          >
            <ChevronRight className="w-5 h-5 text-foreground" />
          </button>
        </div>
      </div>

      <div className="flex gap-2 mt-6 justify-center">
        {journals.map((_, i) => (
          <button
            key={i}
            onClick={() => setCurrent(i)}
            className="w-2 h-2 rounded-full transition-all duration-300"
            style={{
              backgroundColor: i === current ? "hsl(38, 60%, 65%)" : "hsl(30, 10%, 30%)",
              transform: i === current ? "scale(1.3)" : "scale(1)",
            }}
          />
        ))}
      </div>

      <EditJournalDialog
        open={editOpen}
        onOpenChange={setEditOpen}
        journal={journal}
        mode={editMode}
        onSaved={handleSaved}
      />
    </>
  );
}