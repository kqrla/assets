const db = globalThis.__B44_DB__ || { auth:{ isAuthenticated: async()=>false, me: async()=>null }, entities:new Proxy({}, { get:()=>({ filter:async()=>[], get:async()=>null, create:async()=>({}), update:async()=>({}), delete:async()=>({}) }) }), integrations:{ Core:{ UploadFile:async()=>({ file_url:'' }) } } };

import React, { useState } from "react";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";

const COLORS = [
  { value: "red", hex: "#cc4b48" },
  { value: "blue", hex: "#2e95aa" },
  { value: "yellow", hex: "#fed754" },
  { value: "green", hex: "#abc3b5" },
  { value: "navy", hex: "#2c3e6b" },
  { value: "burgundy", hex: "#7a2841" },
  { value: "teal", hex: "#1a8a7a" },
  { value: "coral", hex: "#e8755a" },
];

const STYLES = ["plain", "ruled", "squared", "dotted"];

export default function CreateJournalDialog({ open, onOpenChange, onCreated }) {
  const [title, setTitle] = useState("");
  const [color, setColor] = useState("red");
  const [pageStyle, setPageStyle] = useState("ruled");
  const [saving, setSaving] = useState(false);

  const handleCreate = async () => {
    if (!title.trim()) return;
    setSaving(true);
    const journal = await db.entities.Journal.create({
      title: title.trim(),
      color,
      page_style: pageStyle,
      label: title.trim(),
      pages: [{ content: "", page_number: 1 }],
    });
    setSaving(false);
    setTitle("");
    onCreated(journal);
    onOpenChange(false);
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="bg-card border-border max-w-md">
        <DialogHeader>
          <DialogTitle className="font-heading text-xl lowercase italic">new journal</DialogTitle>
        </DialogHeader>
        <div className="space-y-5 pt-2">
          <div className="space-y-2">
            <Label className="text-sm font-body text-muted-foreground lowercase">title</Label>
            <Input
              value={title}
              onChange={(e) => setTitle(e.target.value)}
              placeholder="My Journal"
              className="bg-secondary border-border"
            />
          </div>

          <div className="space-y-2">
            <Label className="text-sm font-body text-muted-foreground lowercase">cover color</Label>
            <div className="flex gap-2 flex-wrap">
              {COLORS.map((c) => (
                <button
                  key={c.value}
                  onClick={() => setColor(c.value)}
                  className="w-9 h-9 rounded-lg transition-all duration-200"
                  style={{
                    backgroundColor: c.hex,
                    outline: color === c.value ? "2px solid hsl(38, 60%, 65%)" : "none",
                    outlineOffset: 2,
                    transform: color === c.value ? "scale(1.1)" : "scale(1)",
                  }}
                />
              ))}
            </div>
          </div>

          <div className="space-y-2">
            <Label className="text-sm font-body text-muted-foreground lowercase">page style</Label>
            <div className="flex gap-2">
              {STYLES.map((s) => (
                <button
                  key={s}
                  onClick={() => setPageStyle(s)}
                  className="px-3 py-1.5 rounded-md text-xs font-body uppercase tracking-wider transition-all"
                  style={{
                    backgroundColor: pageStyle === s ? "hsl(38, 60%, 65%)" : "hsl(30, 8%, 18%)",
                    color: pageStyle === s ? "hsl(30, 15%, 8%)" : "hsl(30, 10%, 55%)",
                  }}
                >
                  {s}
                </button>
              ))}
            </div>
          </div>

          <Button
            onClick={handleCreate}
            disabled={!title.trim() || saving}
            className="w-full"
          >
            {saving ? "creating…" : "create journal"}
          </Button>
        </div>
      </DialogContent>
    </Dialog>
  );
}