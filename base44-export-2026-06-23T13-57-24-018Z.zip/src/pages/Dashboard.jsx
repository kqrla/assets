const db = globalThis.__B44_DB__ || { auth:{ isAuthenticated: async()=>false, me: async()=>null }, entities:new Proxy({}, { get:()=>({ filter:async()=>[], get:async()=>null, create:async()=>({}), update:async()=>({}), delete:async()=>({}) }) }), integrations:{ Core:{ UploadFile:async()=>({ file_url:'' }) } } };

import React, { useState, useEffect } from "react";

import { Plus, LayoutGrid, Presentation } from "lucide-react";
import NotebookCard from "@/components/planner/NotebookCard";
import SlideshowView from "@/components/planner/SlideshowView";
import CreateJournalDialog from "@/components/planner/CreateJournalDialog";

export default function Dashboard() {
  const [journals, setJournals] = useState([]);
  const [loading, setLoading] = useState(true);
  const [view, setView] = useState("grid");
  const [dialogOpen, setDialogOpen] = useState(false);

  useEffect(() => {
    db.entities.Journal.list("-created_date").then((data) => {
      setJournals(data);
      setLoading(false);
    });
  }, []);

  const handleCreated = (journal) => {
    setJournals((prev) => [journal, ...prev]);
  };

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-background">
        <div className="w-8 h-8 border-4 border-muted border-t-primary rounded-full animate-spin" />
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <header className="border-b border-border">
        <div className="max-w-6xl mx-auto px-6 py-8 flex items-end justify-between">