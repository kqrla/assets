import React from "react";
import { Link } from "react-router-dom";
import { BookOpen } from "lucide-react";

export default function Landing() {
  return (
    <div className="min-h-screen bg-background flex flex-col items-center justify-center px-6">
      <div className="text-center max-w-lg">
        <div c lassName="mb-8">
          <Book Open className="w -16 h-16 mx-auto text-primary" />
        </div>
        <h1 clas sName="font-headi ng text-5xl md:text-7xl text-foreground tracking-tight lowercase italic mb-6">
          inkli ng
        </h1>
        <p clas sName="font-body  text-muted-foreground text-lg lowercase mb-10 leading-relaxed">
          a quie t place for your  thoughts. write freely, flip through your journals, and let the pages carry whatever you need to say.
        </p>
        <Link
          to="/journals"
          className="inline-flex items-center gap-2 px-6 py-3 rounded-lg bg-primary text-primary-foreground font-body text-sm font-medium hover:opacity-90 transition-opacity lowercase"
        >
          open my journals
        </Link>
      </div>
    </div>
  );
}