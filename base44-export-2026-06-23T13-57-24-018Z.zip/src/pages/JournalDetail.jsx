import React, { useState, useEffect, useCallback } from "react";
import { useParams, useNavigate } from "react-router-dom";

import { ArrowLeft, Plus, Save } from "lucide-react";
import { Button } from "@/components/ui/button";
import { useToast } from "@/components/ui/use-toast";

const COLOR_MAP = {
  red: { bg: "#cc4b48", dark: "#9c2e2b" },
  blue: { bg: "#2e95aa", dark: "#1e606e" },
  yellow: { bg: "#fed754", dark: "#ebb501" },
  green: { bg: "#abc3b5", dark: "#7ea38e" },
  navy: { bg: "#2c3e6b", dark: "#1a2540" },
  burgundy: { bg: "#7a2841", dark: "#55192d" },
  teal: { bg: "#1a8a7a", dark: "#0f5c52" },
  coral: { bg: "#e8755a", dark: "#c45a3e" },
};

const PAGE_BG = {
  plain: {},
  ruled: {
    backgroundImage: "linear-gradient(to bottom, transparent 9px, #d4d0c8 1px)",
    backgroundSize: "100% 10px",
  },
  squared: {
    backgroundImage: "linear-gradient(#d4d0c8 1px, transparent 1px), linear-gradient(90deg, #d4d0c8 1px, transparent 1px)",
    backgroundSize: "10px 10px",
  },
  dotted: {
    backgroundImage: "radial-gradient(circle, #bbb 0.8px, transparent 0.8px)",
    backgroundSize: "11px 11px",
  },
};

export default function JournalDetail() {
  const { id } = useParams();
  const navigate = useNavigate();